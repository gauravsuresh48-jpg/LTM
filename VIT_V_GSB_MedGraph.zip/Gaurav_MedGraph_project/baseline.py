"""
Compute normal-traffic baselines from Monday's attack-free capture.
These are used as reference values when assessing Tuesday's traffic.
"""

import json
import pandas as pd

MONDAY = "data/Monday-WorkingHours.pcap_ISCX.csv"
PORTS = {21: "FTP", 22: "SSH", 80: "HTTP", 443: "HTTPS"}
MIN_FLOWS = 50   # don't trust a baseline built from too few flows


def compute_baselines():
    df = pd.read_csv(MONDAY)
    df.columns = df.columns.str.strip()

    # Sanity check - Monday should be entirely benign
    labels = df["Label"].value_counts().to_dict()
    print("Monday label distribution:", labels)

    df = df[df["Label"] == "BENIGN"]

    baselines = {}
    for port, name in PORTS.items():
        flows = df[df["Destination Port"] == port]
        if len(flows) < MIN_FLOWS:
            print(f"  {name:<6} skipped - only {len(flows)} flows")
            continue

        baselines[name] = {
            "port": port,
            "flows_observed": int(len(flows)),
            "median_duration_ms": round(flows["Flow Duration"].median() / 1000, 1),
            "median_fwd_payload_bytes": round(flows["Total Length of Fwd Packets"].median(), 0),
            "median_fwd_packets": round(flows["Total Fwd Packets"].median(), 0),
            "median_bwd_packets": round(flows["Total Backward Packets"].median(), 0),
            "pct_zero_payload": round((flows["Total Length of Fwd Packets"] == 0).mean() * 100, 0),
        }
        print(f"  {name:<6} baseline built from {len(flows):,} flows")

    return baselines


def format_baseline(service, baselines):
    """Return a readable baseline block for the given service, or a note if absent."""
    b = baselines.get(service)
    if not b:
        return f"No historical baseline is available for {service} on this network."

    return (
        f"Historical baseline for normal {service} traffic on this network\n"
        f"(measured from an attack-free capture, {b['flows_observed']:,} flows):\n"
        f"  Median session duration: {b['median_duration_ms']:,.1f} ms\n"
        f"  Median forward payload per connection: {b['median_fwd_payload_bytes']:,.0f} bytes\n"
        f"  Median forward packets per connection: {b['median_fwd_packets']:.0f}\n"
        f"  Median backward packets per connection: {b['median_bwd_packets']:.0f}\n"
        f"  Connections carrying zero payload: {b['pct_zero_payload']:.0f}%"
    )


if __name__ == "__main__":
    print("Computing baselines from Monday (attack-free capture)...\n")
    baselines = compute_baselines()

    with open("baselines.json", "w") as f:
        json.dump(baselines, f, indent=2)

    print("\nSaved to baselines.json\n")
    for service in baselines:
        print(format_baseline(service, baselines))
        print()