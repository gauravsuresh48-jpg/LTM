"""
Multi-class detector: predicts the attack TYPE of each network flow.
Trained on all CICIDS2017 captures (Monday to Friday).

Outputs:
  detector_multi.joblib        model + feature list + class names
  data/holdout_multi.csv       held-out flows the model never saw
  detector_multi_metrics.json  per-class results for the console
"""

import glob
import json

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split

SEED = 42
BENIGN_FRACTION = 0.13      # ~300k of 2.27M benign flows
CAP_PER_CLASS = 60_000      # stops DoS Hulk / PortScan / DDoS dominating
DROP_LABELS = {"Infiltration", "Heartbleed"}   # too few examples

# Host-identifying fields (they reveal WHICH machine, not WHAT it did),
# plus a duplicate column present in the raw files.
EXCLUDE = {"Label", "Init_Win_bytes_forward", "Init_Win_bytes_backward",
           "min_seg_size_forward", "Fwd Header Length.1"}


def clean_label(label):
    label = label.strip()
    if label.startswith("Web Attack"):
        return "Web Attack"
    return label


print("Loading captures...")
frames = []
for path in sorted(glob.glob("data/*-*.pcap_ISCX.csv")):
    df = pd.read_csv(path, encoding="latin-1", low_memory=False)
    df.columns = df.columns.str.strip()
    df["Label"] = df["Label"].map(clean_label)
    df = df[~df["Label"].isin(DROP_LABELS)]

    benign = df[df["Label"] == "BENIGN"].sample(frac=BENIGN_FRACTION, random_state=SEED)
    attacks = df[df["Label"] != "BENIGN"]
    frames.append(pd.concat([benign, attacks]))

    name = path.replace("\\", "/").split("/")[-1]
    print(f"  {name:<62} kept {len(benign) + len(attacks):>9,} flows")

data = pd.concat(frames, ignore_index=True)
del frames

# Cap the very large attack classes (benign is already sampled above).
# A plain loop is used because newer pandas drops the group column in groupby().apply().
parts = []
for label, group in data.groupby("Label"):
    n = len(group) if label == "BENIGN" else min(len(group), CAP_PER_CLASS)
    parts.append(group.sample(n, random_state=SEED))
data = pd.concat(parts, ignore_index=True)
del parts

features = [c for c in data.columns
            if c not in EXCLUDE and pd.api.types.is_numeric_dtype(data[c])]
X = (data[features].replace([np.inf, -np.inf], np.nan).fillna(0)).astype("float32")
y = data["Label"]

print(f"\nTraining pool: {len(data):,} flows, {len(features)} features")
print(y.value_counts().to_string())

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, stratify=y, random_state=SEED)

print("\nTraining random forest (this takes a few minutes)...")
model = RandomForestClassifier(
    n_estimators=100, max_depth=20, min_samples_leaf=2,
    class_weight="balanced_subsample", n_jobs=-1, random_state=SEED)
model.fit(X_train, y_train)

pred = model.predict(X_test)
classes = list(model.classes_)

print("\n" + "=" * 72)
print("HELD-OUT RESULTS (per class)")
print("=" * 72)
report = classification_report(y_test, pred, digits=3, output_dict=True)
print(classification_report(y_test, pred, digits=3))

cm = confusion_matrix(y_test, pred, labels=classes)
print("Confusion matrix (rows = true, columns = predicted):")
print(pd.DataFrame(cm, index=classes, columns=classes).to_string())

importances = sorted(zip(features, model.feature_importances_), key=lambda x: x[1], reverse=True)
print("\nTop 10 features:")
for name, score in importances[:10]:
    print(f"  {name:<30} {score:.3f}")

joblib.dump({"model": model, "features": features, "classes": classes},
            "detector_multi.joblib", compress=3)

holdout = X_test.copy()
holdout["Label"] = y_test.values
holdout.to_csv("data/holdout_multi.csv", index=False)

with open("detector_multi_metrics.json", "w") as f:
    json.dump({
        "classes": classes,
        "report": report,
        "confusion_matrix": cm.tolist(),
        "importances": [[n, float(s)] for n, s in importances[:10]],
        "test_flows": int(len(y_test)),
    }, f, indent=2)

print("\nSaved detector_multi.joblib, data/holdout_multi.csv, detector_multi_metrics.json")