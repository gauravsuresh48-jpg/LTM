import os
from dotenv import load_dotenv
from groq import Groq

print("1. script started")

load_dotenv()
key = os.getenv("GROQ_API_KEY")
print("2. key loaded:", "YES" if key else "NO")

client = Groq(api_key=key)
print("3. client created")

try:
    response = client.chat.completions.create(
        model="openai/gpt-oss-120b",
        messages=[{"role": "user", "content": "Say hello in one short sentence."}]
    )
    print("4. response received")
    print("REPLY:", response.choices[0].message.content)
except Exception as e:
    print("ERROR:", e)