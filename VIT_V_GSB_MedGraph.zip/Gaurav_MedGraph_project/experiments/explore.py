import pandas as pd

df = pd.read_csv("data/Tuesday-WorkingHours.pcap_ISCX.csv")
df.columns = df.columns.str.strip()

print("Does the file have a Timestamp column?")
print([c for c in df.columns if "time" in c.lower() or "stamp" in c.lower()])
print()

groups = {
    "FTP attack":  df[(df.Label == "FTP-Patator")],
    "FTP benign":  df[(df.Label == "BENIGN") & (df["Destination Port"] == 21)],
    "SSH attack":  df[(df.Label == "SSH-Patator")],
    "SSH benign":  df[(df.Label == "BENIGN") & (df["Destination Port"] == 22)],
}

features = [
    "Flow Duration",
    "Total Fwd Packets",
    "Total Backward Packets",
    "Total Length of Fwd Packets",
    "Fwd Packet Length Mean",
    "Bwd Packet Length Mean",
    "Flow IAT Mean",
    "Fwd IAT Mean",
    "Init_Win_bytes_forward",
    "Init_Win_bytes_backward",
    "min_seg_size_forward",
    "Down/Up Ratio",
]

available = [f for f in features if f in df.columns]

for feat in available:
    print(f"--- {feat} ---")
    for name, g in groups.items():
        if len(g) == 0:
            continue
        print(f"  {name:<12} n={len(g):>6}  median={g[feat].median():>14,.1f}  "
              f"mean={g[feat].mean():>14,.1f}")
    print()