import pandas as pd

FILE = "data/Tuesday-WorkingHours.pcap_ISCX.csv"

df = pd.read_csv(FILE)
df.columns = df.columns.str.strip()

attacks = df[df["Label"].isin(["FTP-Patator", "SSH-Patator"])].copy()
benign = df[df["Label"] == "BENIGN"].copy()

SERVICE = {21: "FTP", 22: "SSH"}


def build_incident(flows, label, batch_size=200):
    """Aggregate a batch of flows into one incident-level alert."""
    port = int(flows["Destination Port"].mode()[0])
    service = SERVICE.get(port, {443: "HTTPS", 80: "HTTP"}.get(port, f"port {port}"))
    n = len(flows)
    total_secs = flows["Flow Duration"].sum() / 1_000_000
    avg_ms = flows["Flow Duration"].mean() / 1000
    fwd = int(flows["Total Fwd Packets"].sum())
    bwd = int(flows["Total Backward Packets"].sum())
    bytes_fwd = int(flows["Total Length of Fwd Packets"].sum())
    bytes_per_flow = bytes_fwd / n

    text = (
        f"Network Activity Report\n"
        f"Service: {service} (destination port {port})\n"
        f"Connections observed: {n}\n"
        f"Observation window: {total_secs:.1f} seconds\n"
        f"Average session duration: {avg_ms:.1f} ms\n"
        f"Forward packets: {fwd} | Backward packets: {bwd}\n"
        f"Total forward payload: {bytes_fwd} bytes "
        f"({bytes_per_flow:.1f} bytes per connection)"
    )
    return text, label


incidents = []

# FTP brute-force incident
ftp = attacks[attacks["Label"] == "FTP-Patator"].head(200)
incidents.append(build_incident(ftp, "FTP-Patator"))

# SSH brute-force incident
ssh = attacks[attacks["Label"] == "SSH-Patator"].head(200)
incidents.append(build_incident(ssh, "SSH-Patator"))

# Benign control - so the agent has something non-malicious to compare
normal = benign[benign["Destination Port"] == 443].head(200)
incidents.append(build_incident(normal, "BENIGN"))

for i, (text, label) in enumerate(incidents, 1):
    print(f"--- INCIDENT {i} ---")
    print(text)
    print(f"[ground truth: {label}]\n")