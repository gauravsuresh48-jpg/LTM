import pandas as pd

FILE = "data/Tuesday-WorkingHours.pcap_ISCX.csv"

print("Loading dataset...")
df = pd.read_csv(FILE)

# CICIDS2017 column names have leading spaces - strip them
df.columns = df.columns.str.strip()

print(f"Rows: {len(df):,}")
print(f"Columns: {len(df.columns)}")
print()
print("Label distribution:")
print(df["Label"].value_counts())
print()
print("Sample columns:")
print(list(df.columns[:15]))