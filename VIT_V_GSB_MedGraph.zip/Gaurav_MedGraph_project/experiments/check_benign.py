import pandas as pd
from pipeline import build_incident
from baseline import compute_baselines, format_baseline

df = pd.read_csv("data/Tuesday-WorkingHours.pcap_ISCX.csv")
df.columns = df.columns.str.strip()
benign = df[df["Label"] == "BENIGN"]
attack = df[df["Label"] == "FTP-Patator"]

baselines = compute_baselines()

print("\n" + "=" * 60)
print("WHAT THE AGENT SEES FOR *BENIGN* FTP (incident #11)")
print("=" * 60)
b_ftp = benign[benign["Destination Port"] == 21]
text, _ = build_incident(b_ftp.sample(200, random_state=42), "BENIGN")
print(text)
print()
print(format_baseline("FTP", baselines))

print("\n" + "=" * 60)
print("WHAT THE AGENT SEES FOR *ATTACK* FTP (incident #1)")
print("=" * 60)
text, _ = build_incident(attack.sample(200, random_state=42), "FTP-Patator")
print(text)
print()
print(format_baseline("FTP", baselines))