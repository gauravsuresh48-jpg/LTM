import os
import json
import pandas as pd
from dotenv import load_dotenv
from groq import Groq

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL = "openai/gpt-oss-120b"

FILE = "data/Tuesday-WorkingHours.pcap_ISCX.csv"
SERVICE = {21: "FTP", 22: "SSH", 443: "HTTPS", 80: "HTTP"}

SYSTEM_PROMPT = """You are a Log Analysis Agent in a security operations pipeline.

You receive a network activity report and extract structured findings.
Judge the activity only from the numbers provided. Do not assume it is
malicious or benign before analysing.

Return ONLY valid JSON with these keys:
- service: the service or protocol involved
- connection_count: number of connections observed
- observed_behaviour: one sentence describing the traffic pattern
- suspicious_indicators: list of specific anomalies found (empty list if none)
- assessment: one of "suspicious" or "normal"
- reasoning: one sentence explaining the assessment

No markdown, no explanation outside the JSON."""


def build_incident(flows, label):
    port = int(flows["Destination Port"].mode()[0])
    service = SERVICE.get(port, f"port {port}")
    n = len(flows)
    total_secs = flows["Flow Duration"].sum() / 1_000_000
    avg_ms = flows["Flow Duration"].mean() / 1000
    fwd = int(flows["Total Fwd Packets"].sum())
    bwd = int(flows["Total Backward Packets"].sum())
    bytes_fwd = int(flows["Total Length of Fwd Packets"].sum())

    text = (
        f"Network Activity Report\n"
        f"Service: {service} (destination port {port})\n"
        f"Connections observed: {n}\n"
        f"Observation window: {total_secs:.1f} seconds\n"
        f"Average session duration: {avg_ms:.1f} ms\n"
        f"Forward packets: {fwd} | Backward packets: {bwd}\n"
        f"Total forward payload: {bytes_fwd} bytes "
        f"({bytes_fwd/n:.1f} bytes per connection)"
    )
    return text, label


def log_analysis_agent(report_text):
    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": report_text}
        ],
        temperature=0
    )
    raw = response.choices[0].message.content.strip()
    raw = raw.replace("```json", "").replace("```", "").strip()
    return json.loads(raw)


print("=" * 70)
print("MULTI-AGENT CYBERSECURITY INVESTIGATION - PHASE 1 DEMO")
print("=" * 70)

print("\n[1] Loading CICIDS2017 dataset...")
df = pd.read_csv(FILE)
df.columns = df.columns.str.strip()
print(f"    Loaded {len(df):,} network flows")
print(f"    Label distribution:")
for label, count in df["Label"].value_counts().items():
    print(f"      {label:<15} {count:>8,}")

print("\n[2] Building incident reports from raw flows...")
attacks = df[df["Label"].isin(["FTP-Patator", "SSH-Patator"])]
benign = df[df["Label"] == "BENIGN"]

incidents = [
    build_incident(attacks[attacks["Label"] == "FTP-Patator"].head(200), "FTP-Patator"),
    build_incident(attacks[attacks["Label"] == "SSH-Patator"].head(200), "SSH-Patator"),
    build_incident(benign[benign["Destination Port"] == 443].head(200), "BENIGN"),
]
print(f"    Generated {len(incidents)} incident reports")

print("\n[3] Running Log Analysis Agent on each incident...\n")

correct = 0
for i, (text, truth) in enumerate(incidents, 1):
    print("-" * 70)
    print(f"INCIDENT {i}")
    print("-" * 70)
    print(text)
    print()

    result = log_analysis_agent(text)
    print("AGENT OUTPUT:")
    print(json.dumps(result, indent=2))

    expected = "normal" if truth == "BENIGN" else "suspicious"
    match = result.get("assessment") == expected
    correct += match

    print(f"\nGround truth : {truth}  (expected: {expected})")
    print(f"Agent said   : {result.get('assessment')}  ->  {'CORRECT' if match else 'INCORRECT'}")
    print()

print("=" * 70)
print(f"RESULT: {correct}/{len(incidents)} incidents correctly assessed")
print("=" * 70)