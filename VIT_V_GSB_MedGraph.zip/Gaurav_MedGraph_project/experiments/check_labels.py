"""
Counts the flows for every label across all CICIDS2017 captures.
Reads only the Label column, so it is fast and uses little memory.
"""

import glob
import pandas as pd

files = sorted(glob.glob("data/*-*.pcap_ISCX.csv"))
print(f"Found {len(files)} capture files\n")

total = pd.Series(dtype="int64")

for path in files:
    labels = pd.read_csv(
        path,
        usecols=lambda c: c.strip() == "Label",
        encoding="latin-1",
    ).iloc[:, 0].str.strip()
    counts = labels.value_counts()
    total = total.add(counts, fill_value=0)
    print(f"{path.split('/')[-1].split(chr(92))[-1]}")
    for label, n in counts.items():
        print(f"    {label:<35} {n:>10,}")
    print()

print("=" * 50)
print("TOTAL ACROSS ALL DAYS")
print("=" * 50)
for label, n in total.sort_values(ascending=False).items():
    print(f"  {label:<35} {int(n):>10,}")