"""
Train a flow-level attack detector on CICIDS2017.

Design:
  - Trained on Monday (benign only) + a training slice of Tuesday's attacks
  - Evaluated later on a held-out slice of Tuesday that the model never sees
  - Simple, interpretable model (decision tree) so its logic can be explained
"""

import json
import pandas as pd
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import classification_report, confusion_matrix
import joblib

MONDAY = "data/Monday-WorkingHours.pcap_ISCX.csv"
TUESDAY = "data/Tuesday-WorkingHours.pcap_ISCX.csv"

# Behavioural flow features only.
# Init_Win_bytes_* and min_seg_size_forward are excluded deliberately: they
# reflect the sending host's TCP stack rather than attack behaviour, and a
# model using them learns which machine sent the traffic, not what it did.
FEATURES = [
    "Flow Duration",
    "Total Fwd Packets",
    "Total Backward Packets",
    "Total Length of Fwd Packets",
    "Total Length of Bwd Packets",
    "Fwd Packet Length Mean",
    "Bwd Packet Length Mean",
    "Fwd Packet Length Std",
    "Bwd Packet Length Std",
    "Flow IAT Mean",
    "Flow IAT Std",
    "Fwd IAT Mean",
    "Fwd IAT Std",
    "Down/Up Ratio",
    "Average Packet Size",
]

TRAIN_SEED = 42
HOLDOUT_SEED = 7          # different seed -> different rows for evaluation
HOLDOUT_FRACTION = 0.4    # 40% of Tuesday is reserved and never trained on


def load(path):
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    return df


print("Loading data...")
monday = load(MONDAY)
tuesday = load(TUESDAY)

print(f"  Monday : {len(monday):,} flows (all benign)")
print(f"  Tuesday: {len(tuesday):,} flows")

# ---- Split Tuesday into train and holdout FIRST, before any training ----
tuesday = tuesday.sample(frac=1, random_state=HOLDOUT_SEED).reset_index(drop=True)
split_at = int(len(tuesday) * (1 - HOLDOUT_FRACTION))
tues_train = tuesday.iloc[:split_at]
tues_holdout = tuesday.iloc[split_at:]

print(f"\nTuesday split:")
print(f"  training portion : {len(tues_train):,} flows")
print(f"  held-out portion : {len(tues_holdout):,} flows  (never seen during training)")

# Save the holdout so the evaluation uses exactly these rows
tues_holdout.to_csv("data/tuesday_holdout.csv", index=False)

# ---- Build the training set ----
train = pd.concat([monday, tues_train], ignore_index=True)
train["is_attack"] = (train["Label"] != "BENIGN").astype(int)

X = train[FEATURES].replace([float("inf"), float("-inf")], pd.NA).fillna(0)
y = train["is_attack"]

print(f"\nTraining set: {len(X):,} flows "
      f"({y.sum():,} attack, {(~y.astype(bool)).sum():,} benign)")

# max_depth keeps the tree small enough to read and print
model = DecisionTreeClassifier(
    max_depth=6,
    min_samples_leaf=100,
    class_weight={0: 1, 1: 20},   # attacks matter more, but not 95x more
    random_state=TRAIN_SEED
)
model.fit(X, y)

print("\nLearned decision rules:")
print(export_text(model, feature_names=FEATURES, max_depth=3))

# ---- Evaluate on the held-out portion ----
holdout = tues_holdout.copy()
holdout["is_attack"] = (holdout["Label"] != "BENIGN").astype(int)
Xh = holdout[FEATURES].replace([float("inf"), float("-inf")], pd.NA).fillna(0)
yh = holdout["is_attack"]

pred = model.predict(Xh)

print("\n" + "=" * 60)
print("FLOW-LEVEL PERFORMANCE ON HELD-OUT DATA")
print("=" * 60)
print(classification_report(yh, pred, target_names=["benign", "attack"], digits=3))

tn, fp, fn, tp = confusion_matrix(yh, pred).ravel()
print("Confusion matrix:")
print(f"                   predicted attack   predicted benign")
print(f"  actually attack  {tp:>16,}   {fn:>16,}")
print(f"  actually benign  {fp:>16,}   {tn:>16,}")

# ---- Feature importances, useful for the report ----
importances = sorted(
    zip(FEATURES, model.feature_importances_),
    key=lambda x: x[1], reverse=True
)
print("\nMost informative features:")
for name, score in importances[:6]:
    if score > 0:
        print(f"  {name:<32} {score:.3f}")

joblib.dump({"model": model, "features": FEATURES}, "detector.joblib")
print("\nSaved model to detector.joblib")
print("Saved held-out evaluation data to data/tuesday_holdout.csv")