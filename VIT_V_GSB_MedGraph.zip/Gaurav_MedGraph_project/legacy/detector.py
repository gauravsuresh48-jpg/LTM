"""
Flow-level attack detector used as the perception layer of the pipeline.
Produces quantitative findings that the agents then investigate and explain.
"""

import joblib
import pandas as pd

_bundle = joblib.load("detector.joblib")
MODEL = _bundle["model"]
FEATURES = _bundle["features"]


def score_flows(flows):
    """Run the detector over a set of flows and summarise the result."""
    X = flows[FEATURES].replace([float("inf"), float("-inf")], pd.NA).fillna(0)

    preds = MODEL.predict(X)
    probs = MODEL.predict_proba(X)[:, 1]

    n = len(flows)
    n_flagged = int(preds.sum())

    return {
        "flows_analysed": n,
        "flows_flagged": n_flagged,
        "pct_flagged": round(100 * n_flagged / n, 1),
        "mean_attack_probability": round(float(probs.mean()), 3),
        "max_attack_probability": round(float(probs.max()), 3),
    }


def describe_detection(result):
    """Render the detector output as text for the agents."""
    return (
        f"Automated Detector Output\n"
        f"Flows analysed: {result['flows_analysed']}\n"
        f"Flows flagged as anomalous: {result['flows_flagged']} "
        f"({result['pct_flagged']}%)\n"
        f"Mean attack probability across flows: {result['mean_attack_probability']}\n"
        f"Peak attack probability: {result['max_attack_probability']}"
    )