"""
Stress test: run DoS Hulk traffic (never seen by the detector or in the
original evaluation) through the pipeline and see how it responds.
"""

import pandas as pd
from pipeline import build_pipeline, build_incident

print("Loading Wednesday capture...")
df = pd.read_csv("data/Wednesday-workingHours.pcap_ISCX.csv")
df.columns = df.columns.str.strip()

dos_hulk = df[df["Label"] == "DoS Hulk"]
print(f"DoS Hulk flows available: {len(dos_hulk):,}")

sample = dos_hulk.sample(200, random_state=42)
alert_text, truth = build_incident(sample, "DoS Hulk")

print("\n" + "=" * 72)
print("INCIDENT TEXT SENT TO THE AGENTS")
print("=" * 72)
print(alert_text)
print(f"[ground truth: {truth}]")

print("\nRunning through the pipeline (this calls the detector + 4 agents)...")
pipeline = build_pipeline()
result = pipeline.invoke({"alert_text": alert_text, "ground_truth": truth})

threat = result["threat_assessment"]
risk = result["risk_assessment"]

print("\n" + "=" * 72)
print("RESULT")
print("=" * 72)
print(f"Predicted attack     : {threat.get('is_attack')}")
print(f"Matched technique    : {threat.get('matched_technique_id')}")
print(f"Confidence           : {threat.get('confidence')}")
print(f"Severity             : {risk.get('severity')}")
print("=" * 72)