"""
Stress test: run DoS slowloris traffic through the pipeline.
Slowloris is a slow, low-bandwidth attack (many held-open connections,
minimal data) - a very different shape from DoS Hulk's high-volume flood.
"""

import pandas as pd
from pipeline import build_pipeline, build_incident

print("Loading Wednesday capture...")
df = pd.read_csv("data/Wednesday-workingHours.pcap_ISCX.csv")
df.columns = df.columns.str.strip()

slowloris = df[df["Label"] == "DoS slowloris"]
print(f"DoS slowloris flows available: {len(slowloris):,}")

sample = slowloris.sample(200, random_state=42)
alert_text, truth = build_incident(sample, "DoS slowloris")

print("\n" + "=" * 72)
print("INCIDENT TEXT SENT TO THE AGENTS")
print("=" * 72)
print(alert_text)
print(f"[ground truth: {truth}]")

print("\nRunning through the pipeline (this calls the detector + 4 agents)...")
pipeline = build_pipeline()
result = pipeline.invoke({"alert_text": alert_text, "ground_truth": truth})

threat = result["threat_assessment"]
risk = result["risk_assessment"]

print("\n" + "=" * 72)
print("RESULT")
print("=" * 72)
print(f"Predicted attack     : {threat.get('is_attack')}")
print(f"Matched technique    : {threat.get('matched_technique_id')}")
print(f"Confidence           : {threat.get('confidence')}")
print(f"Severity             : {risk.get('severity')}")
print("=" * 72)