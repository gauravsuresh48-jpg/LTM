"""
Evaluation of the multi-agent pipeline against CICIDS2017 ground truth.
Samples multiple independent incidents per class and reports standard metrics.
"""

import json
import time
import pandas as pd

from pipeline import build_pipeline, build_incident

INCIDENTS_PER_GROUP = 4    # how many incidents to build per traffic group
FLOWS_PER_INCIDENT = 200     # flows aggregated into one incident
PAUSE_SECONDS = 20            # avoid hitting API rate limits


def make_incident_batches(flows, label, n_incidents, size, seed=42):
    """Split a pool of flows into several independent incidents, sampled randomly."""
    pool = flows.sample(frac=1, random_state=seed).reset_index(drop=True)
    batches = []
    for i in range(n_incidents):
        chunk = pool.iloc[i * size:(i + 1) * size]
        if len(chunk) < size:
            break
        batches.append(build_incident(chunk, label))
    return batches


print("=" * 72)
print("PIPELINE EVALUATION")
print("=" * 72)

print("\nLoading dataset...")
df = pd.read_csv("data/tuesday_holdout.csv")
df.columns = df.columns.str.strip()
print(f"Loaded {len(df):,} flows")

ftp_attack = df[df["Label"] == "FTP-Patator"]
ssh_attack = df[df["Label"] == "SSH-Patator"]
benign = df[df["Label"] == "BENIGN"]

# Benign traffic on the SAME ports the attacks target.
# This is the hardest and most honest test: can the system tell a real
# FTP/SSH session from a brute-force attempt on the same service?
benign_ftp = benign[benign["Destination Port"] == 21]
benign_ssh = benign[benign["Destination Port"] == 22]
benign_https = benign[benign["Destination Port"] == 443]
benign_http = benign[benign["Destination Port"] == 80]

print(f"\nAvailable flows per group:")
print(f"  FTP-Patator (attack) : {len(ftp_attack):,}")
print(f"  SSH-Patator (attack) : {len(ssh_attack):,}")
print(f"  Benign FTP  (port 21): {len(benign_ftp):,}")
print(f"  Benign SSH  (port 22): {len(benign_ssh):,}")
print(f"  Benign HTTPS         : {len(benign_https):,}")
print(f"  Benign HTTP          : {len(benign_http):,}")

groups = [
    (ftp_attack, "FTP-Patator", INCIDENTS_PER_GROUP),
    (ssh_attack, "SSH-Patator", INCIDENTS_PER_GROUP),
    (benign_ftp, "BENIGN", INCIDENTS_PER_GROUP),
    (benign_ssh, "BENIGN", INCIDENTS_PER_GROUP),
    (benign_https, "BENIGN", INCIDENTS_PER_GROUP),
    (benign_http, "BENIGN", INCIDENTS_PER_GROUP),
]

incidents = []
for flows, label, n in groups:
    if len(flows) < FLOWS_PER_INCIDENT:
        print(f"  (skipping a {label} group - only {len(flows)} flows available)")
        continue
    incidents.extend(make_incident_batches(flows, label, n, FLOWS_PER_INCIDENT))

print(f"\nBuilt {len(incidents)} incidents for evaluation")

pipeline = build_pipeline()
rows = []

print("\nRunning pipeline on each incident...\n")

for i, (alert_text, truth) in enumerate(incidents, 1):
    truth_is_attack = truth != "BENIGN"
    service = alert_text.split("Service: ")[1].split(" ")[0]

    try:
        result = pipeline.invoke({"alert_text": alert_text, "ground_truth": truth})
        threat = result["threat_assessment"]
        risk = result["risk_assessment"]

        predicted = bool(threat.get("is_attack"))
        rows.append({
            "incident": i,
            "service": service,
            "ground_truth": truth,
            "truth_is_attack": truth_is_attack,
            "predicted_is_attack": predicted,
            "correct": predicted == truth_is_attack,
            "technique": threat.get("matched_technique_id"),
            "confidence": threat.get("confidence"),
            "severity": risk.get("severity"),
            "error": None,
        })
        mark = "OK " if predicted == truth_is_attack else "MISS"
        print(f"  [{i:>2}/{len(incidents)}] {mark} {service:<6} "
              f"truth={truth:<12} predicted_attack={predicted}")

    except Exception as e:
        rows.append({
            "incident": i, "service": service, "ground_truth": truth,
            "truth_is_attack": truth_is_attack, "predicted_is_attack": None,
            "correct": False, "technique": None, "confidence": None,
            "severity": None, "error": str(e)[:120],
        })
        print(f"  [{i:>2}/{len(incidents)}] ERR {service:<6} {str(e)[:60]}")

    time.sleep(PAUSE_SECONDS)

results = pd.DataFrame(rows)
results.to_csv("evaluation_results.csv", index=False)

# ---------- Metrics ----------
valid = results[results["error"].isna()].copy()
valid["predicted_is_attack"] = valid["predicted_is_attack"].astype(bool)
valid["truth_is_attack"] = valid["truth_is_attack"].astype(bool)
errors = len(results) - len(valid)

tp = int(((valid.truth_is_attack) & (valid.predicted_is_attack)).sum())
tn = int(((~valid.truth_is_attack) & (~valid.predicted_is_attack)).sum())
fp = int(((~valid.truth_is_attack) & (valid.predicted_is_attack)).sum())
fn = int(((valid.truth_is_attack) & (~valid.predicted_is_attack)).sum())

total = tp + tn + fp + fn
accuracy = (tp + tn) / total if total else 0
precision = tp / (tp + fp) if (tp + fp) else 0
recall = tp / (tp + fn) if (tp + fn) else 0
f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0

print("\n" + "=" * 72)
print("RESULTS")
print("=" * 72)
print(f"\nIncidents evaluated : {total}")
if errors:
    print(f"Pipeline errors     : {errors}")

print("\nConfusion matrix:")
print(f"                      predicted attack   predicted normal")
print(f"  actually attack     {tp:>16}   {fn:>16}")
print(f"  actually normal     {fp:>16}   {tn:>16}")

print(f"\nAccuracy  : {accuracy:.1%}   ({tp + tn}/{total} correct)")
print(f"Precision : {precision:.1%}   (of those flagged as attacks, how many really were)")
print(f"Recall    : {recall:.1%}   (of the real attacks, how many were caught)")
print(f"F1 score  : {f1:.3f}")

print("\nAccuracy by service:")
for svc, grp in valid.groupby("service"):
    correct = grp["correct"].sum()
    print(f"  {svc:<6}  {correct}/{len(grp)}  ({correct/len(grp):.0%})")

print("\nTechniques matched on true attacks:")
attack_rows = valid[valid.truth_is_attack & valid.predicted_is_attack]
if len(attack_rows):
    print(attack_rows["technique"].value_counts().to_string())

misses = valid[~valid.correct]
if len(misses):
    print(f"\nMisclassified incidents ({len(misses)}):")
    for _, r in misses.iterrows():
        kind = "false negative" if r.truth_is_attack else "false positive"
        print(f"  #{r.incident} {r.service} - {kind} (truth: {r.ground_truth})")

print("\nFull results written to evaluation_results.csv")
print("=" * 72) 