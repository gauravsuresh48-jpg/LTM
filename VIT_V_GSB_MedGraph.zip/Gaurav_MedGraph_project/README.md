# Multi-Agent SOC Investigation Pipeline

A security operations tool that receives an **unlabelled** batch of network
traffic and investigates it the way an analyst would: decide whether it is an
attack, identify **which of 10 attack types** it is, map it to MITRE ATT&CK,
**gather more evidence when unsure**, rate the risk, and write the incident report.

A trained multi-class detector decides the attack class. Language-model agents
investigate it: they explain the evidence, flag anything unusual, decide whether
more traffic needs to be examined, assess severity and write the report. A
Streamlit console runs cases blind and reveals the true label only after the verdict.

## How it works

```
Multi-class detector → Log Analysis → Knowledge Retrieval → Threat Analysis ──→ Risk Assessment → Report
  (random forest)        (agent)      (MITRE ATT&CK KB)        (agent)    ↑  │       (agent)        (agent)
                                                                          │  ↓
                                                              Evidence gathering (up to 2 rounds)
```

| Stage | What it does |
|---|---|
| Multi-class detector | Random forest on 74 flow features; assigns every flow to BENIGN or one of 10 attack types |
| Log Analysis | Reads telemetry and the detector breakdown; decides suspicious or normal |
| Knowledge Retrieval | Returns the MITRE technique mapped to the detected class, plus keyword matches |
| Threat Analysis | Explains the evidence, raises caveats, and **decides whether more evidence is needed** |
| Evidence gathering | Fetches more traffic from the same source, runs the detector on it, and checks it agrees |
| Risk Assessment | Assigns severity (High / Medium / Low / Informational) and a next step |
| Report Generation | Writes an analyst-ready incident report |

**Evidence loop.** A LangGraph conditional edge lets the Threat agent loop back
for more traffic when its confidence is not high or it has raised a caveat, up
to 2 extra rounds. If the new traffic contradicts the first batch, confidence is
set to low and the case is escalated to an analyst. Confirming evidence never
lowers confidence.

**Division of roles.** The detector decides the attack class, because it uses 74
features per flow and is far more reliable than an LLM reasoning from summary
statistics. The agents cannot overrule it; when the evidence looks unusual they
flag it, investigate further, or escalate.

Agents are orchestrated with LangGraph and run on `gpt-oss-120b` via the Groq API.

## Attack types

| Detector class | MITRE technique |
|---|---|
| FTP-Patator, SSH-Patator | T1110.001 Password Guessing |
| DoS Hulk, GoldenEye, slowloris, Slowhttptest | T1499.002 Service Exhaustion Flood |
| DDoS | T1498 Network Denial of Service |
| PortScan | T1046 Network Service Discovery |
| Web Attack (brute force, XSS, SQL injection) | T1190 Exploit Public-Facing Application |
| Bot | T1071.001 Web Protocols (command and control) |

## Results

**Detector** (128,768 held-out flows)

| Accuracy | Macro F1 | Classes |
|---|---|---|
| 99.1% | 0.949 | 11 (BENIGN + 10 attack types) |

Every attack class scores F1 above 0.96 except Bot, whose flow-level precision
is 0.342. At incident level this stays around 1% of flows, below the 5% alert
threshold, so it does not cause false alarms.

**Full pipeline, blind** (27 incidents of 200 held-out flows)

| Attack vs normal | Attack type | MITRE technique | False alarms | Missed attacks |
|---|---|---|---|---|
| 27/27 | 20/20 | 20/20 | 0 of 7 | 0 of 20 |

**Evidence gathering:** 9 of 27 investigations decided on their own to examine
more traffic before concluding (10 extra rounds in total). In 6 of those 9 the
extra evidence raised confidence to high; no extra batch contradicted the first.

## Limitations

- Each incident contains one traffic type. Real SOC traffic is mixed; grouping
  flows by source IP and time window is the next step and needs the CICIDS2017
  version with IP addresses and timestamps.
- "More traffic from the same source" is simulated as more held-out flows of the
  same traffic, because this dataset version has no source IPs.
- The train/test split is random by flow, so flow-level scores are optimistic.
  The blind incident-level evaluation is the more honest measure.
- Infiltration (36 flows) and Heartbleed (11 flows) were left out: too few to test.
- About 2 incidents per attack type were evaluated.
- The technique comes from a fixed class mapping, so technique accuracy follows
  attack-type accuracy by design.

## Setup

```
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

Create `.env` in the project folder:

```
GROQ_API_KEY=your_key_here
```

Download `MachineLearningCSV.zip` from the
[CICIDS2017 dataset](https://www.unb.ca/cic/datasets/ids-2017.html) and place
all 8 day files in `data/`.

## Running it

| Command | What it does |
|---|---|
| `python train_multiclass.py` | Trains the detector, writes `detector_multi.joblib` and the held-out split |
| `python detector_multi.py` | Detector self-test: one incident per class |
| `python build_kb.py` | Knowledge-base retrieval test |
| `python pipeline.py` | Three blind incidents through the full pipeline, showing evidence rounds |
| `python evaluate_multi.py` | Full blind evaluation (about 25 minutes) |
| `streamlit run app.py` | The investigation console |

## Design notes

- **Leaky features removed.** TCP window size and segment size identify the
  sending machine rather than the attack, so they were excluded.
- **Formatting matters to LLMs.** Durations written as `8,381.0 ms` were misread
  as 8.4 ms. They are now written as `8381.0 ms (8.38 seconds)`.
- **LLMs should not overrule a validated classifier.** In testing, the Threat
  agent relabelled Bot traffic as a port scan and a web attack as a DoS, by
  matching summary statistics to textbook descriptions. The classification is
  now fixed by the detector, and the agent's doubts become caveats and
  evidence requests.
- **Guardrails on the agent's decisions.** The evidence loop is capped at 2
  rounds, normal traffic with almost nothing flagged cannot trigger it, and
  contradicting evidence escalates to an analyst instead of looping.

## Repository layout

- `legacy/` contains version 1, a binary detector covering FTP and SSH brute
  force only, kept for reference.
- `experiments/` contains early exploration scripts.

## Dataset

CICIDS2017, Canadian Institute for Cybersecurity, University of New Brunswick.