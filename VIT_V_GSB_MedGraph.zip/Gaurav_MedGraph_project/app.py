"""
SOC Investigation Console (multi-class, blind mode, evidence gathering, animated)
Run with:  streamlit run app.py
"""

import json
import random
import time
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

st.set_page_config(page_title="SOC Investigation Console", page_icon="◆",
                   layout="wide", initial_sidebar_state="expanded")

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600&display=swap');
:root {
  --base:#0A0F24; --surface:#121A3A; --surface-2:#18224A; --rule:#2B3A73; --rule-soft:#1F2A58;
  --ink:#F1F4FF; --ink-muted:#A9B6E8; --ink-faint:#7D8BC2;
  --threat:#FF4D6D; --clear:#22E3A3; --caution:#FFC233; --agent:#5B8CFF; --violet:#B36BFF; --cyan:#2CD5FF;
}
html, body, [class*="css"], .stApp { font-family:'IBM Plex Sans', system-ui, sans-serif; }
.stApp { background:var(--base); color:var(--ink); }
#MainMenu, footer, header[data-testid="stHeader"] { visibility:hidden; height:0; }
[data-testid="stSidebarCollapsedControl"] { visibility:visible; }
.block-container { padding-top:1.6rem; padding-bottom:4rem; max-width:1180px; }
section[data-testid="stSidebar"] { background:var(--surface); border-right:1px solid var(--rule); }

.masthead { display:flex; align-items:flex-end; justify-content:space-between; gap:1rem;
  border-bottom:1px solid var(--rule); padding-bottom:0.9rem; margin-bottom:0.9rem; flex-wrap:wrap; }
.masthead h1 { font-size:1.45rem; font-weight:600; margin:0; color:var(--ink); }
.masthead .sub { font-size:0.85rem; color:var(--ink-muted); margin:0.2rem 0 0 0; }
.status { display:flex; align-items:center; gap:0.5rem; font-size:0.8rem; color:var(--ink-muted); }
.status .dot { width:0.5rem; height:0.5rem; border-radius:50%; background:var(--clear); }

.strip { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); border:1px solid var(--rule);
  background:var(--surface); margin-bottom:1.6rem; }
.strip > div { padding:0.7rem 1rem; border-right:1px solid var(--rule-soft); }
.strip > div:last-child { border-right:none; }
.strip .l { font-size:0.76rem; color:var(--ink-faint); }
.strip .v { font-family:'IBM Plex Mono', monospace; font-size:1.02rem; color:var(--ink); margin-top:0.15rem; }

.spine { position:relative; padding-left:2.6rem; }
.spine::before { content:""; position:absolute; left:0.62rem; top:0.7rem; bottom:0.7rem; width:1px; background:var(--rule); }
.station { position:relative; padding-bottom:1.5rem; }
.station::before { content:""; position:absolute; left:-2.28rem; top:0.32rem; width:0.72rem; height:0.72rem;
  border-radius:50%; background:var(--base); border:1px solid var(--rule-soft); }
.station.active::before { border-color:var(--agent); background:var(--agent); box-shadow:0 0 0 4px rgba(91,140,255,0.16); }
.station.done::before { border-color:var(--agent); background:var(--agent); }
.station.loop::before { border-color:var(--caution); background:var(--caution); }
.station-name { font-size:0.93rem; font-weight:600; color:var(--ink-faint); margin-bottom:0.15rem; }
.station-name .t { font-family:'IBM Plex Mono', monospace; font-weight:400; font-size:0.76rem; color:var(--ink-faint); margin-left:0.6rem; }
.station.active .station-name, .station.done .station-name, .station.loop .station-name { color:var(--ink); }
.station-role { font-size:0.8rem; color:var(--ink-faint); }
.station.done .station-role, .station.active .station-role, .station.loop .station-role { color:var(--ink-muted); }
.station-body { margin-top:0.7rem; background:var(--surface); border:1px solid var(--rule);
  border-left:2px solid var(--agent); padding:0.85rem 1rem; font-size:0.86rem; line-height:1.55; }
.station.loop .station-body { border-left-color:var(--caution); }
.station-body .k { color:var(--ink-muted); }
.station-body .v { color:var(--ink); }
.station-body .cav { color:var(--caution); }
.station-body .ok { color:var(--clear); }
.station-body .no { color:var(--threat); }
.station-body ul { margin:0.35rem 0 0 1rem; padding:0; }

.evidence { background:var(--surface); border:1px solid var(--rule); padding:1.05rem 1.2rem; margin-bottom:1.5rem; }
.evidence h3 { font-size:0.86rem; font-weight:600; color:var(--ink); margin:0 0 0.6rem 0; }
.evidence p { font-size:0.86rem; color:var(--ink-muted); line-height:1.6; margin:0 0 0.5rem 0; }
.evidence.warn { border-left:2px solid var(--caution); }
.evidence.bad { border-left:2px solid var(--threat); }
.evidence.good { border-left:2px solid var(--clear); }

.metric-row { display:flex; justify-content:space-between; align-items:baseline; gap:1rem; padding:0.3rem 0;
  border-bottom:1px solid var(--rule-soft); font-size:0.86rem; }
.metric-row:last-child { border-bottom:none; }
.metric-row .label { color:var(--ink-muted); }
.metric-row .value { font-family:'IBM Plex Mono', monospace; color:var(--ink); text-align:right; }

.kpis { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:0.8rem; margin-bottom:1.4rem; }
.kpi { background:var(--surface); border:1px solid var(--rule); padding:0.9rem 1rem; }
.kpi .l { font-size:0.78rem; color:var(--ink-muted); }
.kpi .v { font-family:'IBM Plex Mono', monospace; font-size:1.6rem; color:var(--ink); margin-top:0.2rem; }
.kpi .h { font-size:0.74rem; color:var(--ink-faint); margin-top:0.2rem; }

.tbl { width:100%; border-collapse:collapse; font-size:0.82rem; }
.tbl th { text-align:left; font-weight:500; color:var(--ink-faint); padding:0.5rem 0.6rem; border-bottom:1px solid var(--rule); }
.tbl td { padding:0.45rem 0.6rem; border-bottom:1px solid var(--rule-soft); color:var(--ink) !important; }
.tbl td.mono { font-family:'IBM Plex Mono', monospace; }
.tbl td.ok, .tbl td .ok { color:var(--clear) !important; }
.tbl td.no, .tbl td .no { color:var(--threat) !important; }
.tbl td.warnc { color:var(--caution) !important; }
.heat td, .heat th { text-align:center; font-family:'IBM Plex Mono', monospace; font-size:0.72rem; padding:0.3rem 0.35rem; }
.heat th { color:var(--ink-faint); font-weight:500; }
.heat td.rowh { text-align:left; color:var(--ink-muted) !important; font-family:'IBM Plex Sans', sans-serif; }
.scroll { overflow-x:auto; }

.bar-row { display:grid; grid-template-columns:11rem 1fr 7.5rem; align-items:center; gap:0.8rem; padding:0.28rem 0; font-size:0.83rem; }
.bar-row .n { color:var(--ink-muted); }
.bar-track { background:var(--rule-soft); height:0.5rem; }
.bar-fill { height:100%; }
.bar-row .s { font-family:'IBM Plex Mono', monospace; color:var(--ink); text-align:right; font-size:0.78rem; }

.verdict { display:flex; align-items:center; gap:1.1rem; border:1px solid var(--rule); background:var(--surface-2);
  padding:1rem 1.2rem; margin-bottom:1.5rem; flex-wrap:wrap; }
.verdict.threat { border-left:3px solid var(--threat); }
.verdict.clear { border-left:3px solid var(--clear); }
.verdict .headline { font-size:1.12rem; font-weight:600; margin:0; }
.verdict.threat .headline { color:var(--threat); }
.verdict.clear .headline { color:var(--clear); }
.verdict .detail { font-size:0.84rem; color:var(--ink-muted); margin:0.2rem 0 0 0; max-width:70ch; }
.verdict .truth { margin-left:auto; text-align:right; font-size:0.78rem; color:var(--ink-faint); min-width:11rem; }
.verdict .truth .val { display:block; font-family:'IBM Plex Mono', monospace; font-size:0.92rem; margin-top:0.15rem; }
.verdict .truth .val.match { color:var(--clear); }
.verdict .truth .val.miss { color:var(--threat); }

.chip { display:inline-block; font-family:'IBM Plex Mono', monospace; font-size:0.74rem; font-weight:600;
  padding:0.15rem 0.5rem; border:1px solid currentColor; }
.chip.High { color:var(--threat); } .chip.Medium { color:var(--caution); }
.chip.Low { color:var(--agent); } .chip.Informational { color:var(--ink-muted); }

.report { background:var(--surface); border:1px solid var(--rule); padding:1.3rem 1.5rem;
  font-family:'IBM Plex Mono', monospace; font-size:0.82rem; line-height:1.7; white-space:pre-wrap; color:var(--ink); }
.telemetry { font-family:'IBM Plex Mono', monospace; font-size:0.79rem; line-height:1.6; color:var(--ink-muted);
  white-space:pre-wrap; background:var(--base); border:1px solid var(--rule-soft); padding:0.9rem 1rem; }
.tech { display:inline-block; font-family:'IBM Plex Mono', monospace; font-size:0.75rem; color:var(--ink-muted);
  border:1px solid var(--rule); padding:0.18rem 0.5rem; margin:0 0.3rem 0.3rem 0; }
.tech.hit { color:var(--agent); border-color:var(--agent); }
.sec { font-size:0.82rem; font-weight:600; color:var(--ink-muted); border-bottom:1px solid var(--rule);
  padding-bottom:0.45rem; margin:2rem 0 1.1rem 0; }
.lede { font-size:0.88rem; color:var(--ink-muted); line-height:1.65; margin-bottom:1.4rem; max-width:70ch; }

.arch { display:flex; align-items:stretch; flex-wrap:wrap; margin:0.4rem 0 0.6rem 0; }
.arch .node { background:var(--surface); border:1px solid var(--rule); padding:0.75rem 0.85rem; min-width:8rem; flex:1; }
.arch .node.ml { border-top:2px solid var(--caution); }
.arch .node.llm { border-top:2px solid var(--agent); }
.arch .node.kb { border-top:2px solid var(--clear); }
.arch .node .t { font-size:0.84rem; font-weight:600; color:var(--ink); }
.arch .node .d { font-size:0.75rem; color:var(--ink-muted); margin-top:0.25rem; line-height:1.45; }
.arch .arrow { display:flex; align-items:center; padding:0 0.35rem; color:var(--ink-faint); }
.loopnote { font-size:0.8rem; color:var(--caution); margin-bottom:1.4rem; }

section[data-testid="stSidebar"] .stButton,
section[data-testid="stSidebar"] div[data-testid="stElementContainer"]:has(.stButton) { width:100% !important; }
.stButton > button { width:100%; background:var(--agent); color:#0A0F24; border:none; border-radius:0;
  font-weight:600; font-size:0.88rem; padding:0.55rem 0; }
.stButton > button:hover { background:#8FB0FF; color:#0A0F24; }
.stDownloadButton > button { background:transparent; color:var(--agent); border:1px solid var(--agent);
  border-radius:0; padding:0.4rem 1rem; }
.stTabs [data-baseweb="tab-list"] { gap:1.6rem; border-bottom:1px solid var(--rule); }
.stTabs [data-baseweb="tab"] { background:transparent; color:var(--ink-faint); padding:0.5rem 0; font-size:0.9rem; font-weight:500; }
.stTabs [aria-selected="true"] { color:var(--ink); }


/* ---------- Motion ---------- */
@property --num { syntax: '<integer>'; initial-value: 0; inherits: false; }
.count { animation: countup 1.4s cubic-bezier(.2,.7,.2,1) forwards; counter-reset: num var(--num); }
.count::before { content: counter(num); }
@keyframes countup { from { --num: 0; } to { --num: var(--to); } }

@keyframes rise { from { opacity:0; transform:translateY(10px); } to { opacity:1; transform:none; } }
@keyframes pulse { 0%,100% { box-shadow:0 0 0 3px rgba(91,140,255,0.18); } 50% { box-shadow:0 0 0 9px rgba(91,140,255,0.04); } }
@keyframes pulseY { 0%,100% { box-shadow:0 0 0 3px rgba(255,194,51,0.22); } 50% { box-shadow:0 0 0 9px rgba(255,194,51,0.04); } }
@keyframes flashR { 0% { box-shadow:0 0 0 0 rgba(255,77,109,0.55); } 100% { box-shadow:0 0 0 18px rgba(255,77,109,0); } }
@keyframes flashG { 0% { box-shadow:0 0 0 0 rgba(34,227,163,0.55); } 100% { box-shadow:0 0 0 18px rgba(34,227,163,0); } }
@keyframes pop { 0% { transform:scale(.4); opacity:0; } 70% { transform:scale(1.15); opacity:1; } 100% { transform:scale(1); } }
@keyframes caret { 50% { opacity:0; } }
@keyframes dash { to { stroke-dashoffset: -16; } }

.station.fresh { animation: rise .45s ease-out both; }
.station.active::before { animation: pulse 1.3s ease-in-out infinite; }
.station.loop.active::before { animation: pulseY 1.3s ease-in-out infinite; }
.verdict { animation: rise .5s ease-out both; }
.verdict.threat { animation: rise .5s ease-out both, flashR 1.1s ease-out .2s 2; }
.verdict.clear { animation: rise .5s ease-out both, flashG 1.1s ease-out .2s 2; }
.verdict .truth .val .mark { display:inline-block; animation: pop .6s ease-out .6s both; }
.kpi, .strip > div { animation: rise .5s ease-out both; }
.kpi:nth-child(2), .strip > div:nth-child(2) { animation-delay: .08s; }
.kpi:nth-child(3), .strip > div:nth-child(3) { animation-delay: .16s; }
.kpi:nth-child(4), .strip > div:nth-child(4) { animation-delay: .24s; }
.report .caret { display:inline-block; width:.55em; height:1em; background:var(--agent); vertical-align:-2px;
  margin-left:2px; animation: caret .8s step-end infinite; }

/* ---------- Live pipeline diagram ---------- */
.flow { background:var(--surface); border:1px solid var(--rule); padding:1rem 1rem 0.6rem 1rem; margin-bottom:1.4rem; }
.flow-row { display:flex; align-items:stretch; gap:0; }
.fnode { flex:1; min-width:0; border:1px solid var(--rule-soft); background:var(--base); padding:0.6rem 0.55rem;
  text-align:center; transition: all .3s ease; position:relative; }
.fnode .ft { font-size:0.8rem; font-weight:600; color:var(--ink-faint); }
.fnode .fs { font-family:'IBM Plex Mono', monospace; font-size:0.68rem; color:var(--ink-faint); margin-top:0.2rem; }
.fnode.done { border-color:var(--agent); }
.fnode.done .ft { color:var(--ink); }
.fnode.done .fs { color:var(--clear); }
.fnode.active { border-color:var(--agent); background:rgba(91,140,255,0.12); animation: pulse 1.3s ease-in-out infinite; }
.fnode.active .ft { color:var(--ink); }
.fnode.active .fs { color:var(--agent); }
.fnode.ml.done, .fnode.ml.active { border-color:var(--caution); }
.fnode.kb.done { border-color:var(--clear); }
.flink { display:flex; align-items:center; padding:0 0.25rem; color:var(--ink-faint); font-size:0.9rem; }
.flink.lit { color:var(--agent); }
.floop { display:flex; justify-content:center; margin-top:0.45rem; }
.floop .lp { display:flex; align-items:center; gap:0.5rem; font-size:0.74rem; color:var(--ink-faint);
  border:1px dashed var(--rule); padding:0.3rem 0.8rem; }
.floop .lp.active { color:var(--caution); border-color:var(--caution); animation: pulseY 1.3s ease-in-out infinite; }
.floop .lp.done { color:var(--caution); border-color:rgba(255,194,51,0.5); }
.floop .lp.skip { opacity:0.6; }
.floop svg { width:18px; height:18px; }
.floop .lp.active svg circle { stroke-dasharray:4 4; animation: dash .6s linear infinite; }

/* ---------- Bigger type, vivid accents ---------- */
html { font-size: 18px; }
.stApp { background:
  radial-gradient(1200px 600px at 85% -10%, rgba(179,107,255,0.16), transparent 60%),
  radial-gradient(900px 500px at -10% 20%, rgba(44,213,255,0.10), transparent 60%),
  var(--base); }
.masthead h1 { font-size:2rem; font-weight:600; background:linear-gradient(90deg,#5B8CFF,#B36BFF 55%,#FF4D9A);
  -webkit-background-clip:text; background-clip:text; color:transparent; }
.masthead .sub { font-size:1rem; }
.strip .l, .kpi .l { font-size:0.85rem; color:var(--ink-muted); }
.strip .v { font-size:1.35rem; font-weight:600; background:linear-gradient(90deg,#2CD5FF,#5B8CFF);
  -webkit-background-clip:text; background-clip:text; color:transparent; }
.kpi .v { font-size:2rem; font-weight:600; background:linear-gradient(90deg,#22E3A3,#2CD5FF);
  -webkit-background-clip:text; background-clip:text; color:transparent; }
.kpi .h { font-size:0.8rem; }
.kpi, .strip, .evidence, .flow, .station-body, .report { border-radius:10px; }
.kpi { background:linear-gradient(160deg, var(--surface-2), var(--surface)); }
.sec { font-size:0.95rem; color:var(--ink); letter-spacing:0.01em; }
.lede { font-size:1rem; }
.evidence h3 { font-size:1rem; }
.evidence p, .metric-row, .station-body { font-size:0.95rem; }
.station-name { font-size:1.05rem; }
.station-role { font-size:0.88rem; }
.tbl { font-size:0.9rem; }
.heat td, .heat th { font-size:0.8rem; }
.report { font-size:0.9rem; }
.fnode { border-radius:8px; }
.fnode .ft { font-size:0.9rem; }
.fnode .fs { font-size:0.78rem; }
.fnode.ml.done, .fnode.ml.active { border-color:var(--caution); background:rgba(255,194,51,0.10); }
.fnode.ml .ft { color:var(--caution); }
.fnode.llm.done { border-color:var(--agent); background:rgba(91,140,255,0.10); }
.fnode.kb.done { border-color:var(--clear); background:rgba(34,227,163,0.10); }
.fnode.done .fs { color:var(--cyan); }
.floop .lp { font-size:0.85rem; border-radius:999px; }
.flink.lit { color:var(--violet); }
.station.done::before { background:linear-gradient(135deg,#5B8CFF,#B36BFF); border-color:transparent; }
.station-body { border-left-color:var(--violet); }
.tech.hit { color:var(--cyan); border-color:var(--cyan); background:rgba(44,213,255,0.08); }
.chip { border-radius:6px; }
.chip.High { background:rgba(255,77,109,0.12); } .chip.Medium { background:rgba(255,194,51,0.12); }
.verdict { border-radius:10px; background:linear-gradient(120deg, var(--surface-2), var(--surface)); }
.verdict .headline { font-size:1.35rem; }
.verdict .detail { font-size:0.95rem; }
.verdict .truth .val { font-size:1.1rem; }
.stButton > button { background:linear-gradient(90deg,#5B8CFF,#B36BFF); color:#FFFFFF; border-radius:8px; font-size:0.95rem; }
.stButton > button:hover { background:linear-gradient(90deg,#7AA2FF,#C58BFF); color:#FFFFFF; }
.stDownloadButton > button { border-radius:8px; }
.stTabs [data-baseweb="tab"] { font-size:1rem; }
.stTabs [aria-selected="true"] { color:#FFFFFF; }
.arch .node { border-radius:8px; }
.arch .node .t { font-size:0.95rem; }
.arch .node .d { font-size:0.82rem; }
.loopnote { font-size:0.9rem; }


@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after { animation: none !important; transition: none !important; }
}
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)

HOLDOUT = "data/holdout_multi.csv"
BASE_STAGES = [
    ("Log Analysis", "Reads the telemetry and detector output"),
    ("Knowledge Retrieval", "Pulls MITRE ATT&CK techniques for the detected class"),
    ("Threat Analysis", "Explains the attack type, flags caveats, decides if more evidence is needed"),
    ("Risk Assessment", "Assigns severity and recommends action"),
    ("Report Generation", "Writes the analyst-ready incident report"),
]


# ----------------------------------------------------------------------------
# Data and backend
# ----------------------------------------------------------------------------
@st.cache_resource(show_spinner=False)
def load_backend():
    import pipeline as P
    from detector_multi import score_flows
    return {"P": P, "score": score_flows}


@st.cache_data(show_spinner=False)
def load_holdout():
    return pd.read_csv(HOLDOUT) if Path(HOLDOUT).exists() else None


@st.cache_data(show_spinner=False)
def load_metrics():
    p = Path("detector_multi_metrics.json")
    return json.loads(p.read_text()) if p.exists() else None


@st.cache_data(show_spinner=False)
def load_evaluation():
    p = Path("evaluation_multi_results.csv")
    if not p.exists():
        return None
    res = pd.read_csv(p)
    v = res[res["error"].isna()].copy()
    if v.empty:
        return None
    for c in ("truth_is_attack", "predicted_is_attack", "detect_ok", "type_ok", "technique_ok"):
        v[c] = v[c].astype(bool)
    v["predicted_class"] = v["predicted_class"].fillna("BENIGN")
    if "evidence_rounds" not in v.columns:
        v["evidence_rounds"] = 0
    v["evidence_rounds"] = v["evidence_rounds"].fillna(0).astype(int)
    att = v[v["truth_is_attack"]]
    return {
        "rows": v, "errors": len(res) - len(v), "total": len(v),
        "detect_acc": v["detect_ok"].mean(),
        "type_acc": v["type_ok"].mean(),
        "attack_type_acc": att["type_ok"].mean() if len(att) else 0,
        "false_alarms": int((~v["truth_is_attack"] & v["predicted_is_attack"]).sum()),
        "missed": int((v["truth_is_attack"] & ~v["predicted_is_attack"]).sum()),
        "n_attack": len(att), "n_benign": int((~v["truth_is_attack"]).sum()),
        "gathered": int((v["evidence_rounds"] > 0).sum()),
        "extra_rounds": int(v["evidence_rounds"].sum()),
    }


def esc(x):
    return str(x).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def text_or_dash(x):
    """Show a dash instead of 'nan' when a value is missing."""
    if x is None or (not isinstance(x, str) and pd.isna(x)):
        return "—"
    s = str(x).strip()
    return "—" if s.lower() in ("", "nan", "none", "null") else esc(s)


def pct(x):
    return f"{x:.1%}"


def parse_telemetry(alert_text):
    rows = []
    for line in alert_text.split("Automated Detector Output")[0].splitlines():
        if ":" in line and not line.startswith("Network Activity"):
            k, v = line.split(":", 1)
            rows.append((k.strip(), v.strip()))
    return rows


def breakdown_html(breakdown):
    rows = ""
    for b in breakdown:
        color = "var(--clear)" if b["class"] == "BENIGN" else "var(--threat)"
        rows += (f"<div class='bar-row'><span class='n'>{esc(b['class'])}</span>"
                 f"<div class='bar-track'><div class='bar-fill' style='width:{b['pct']}%;background:{color}'></div></div>"
                 f"<span class='s'>{b['pct']}% · conf {b['mean_confidence']}</span></div>")
    return rows


def countup(text):
    """Animate the leading whole number of a value (e.g. 99.1% counts 0 -> 99, then shows .1%)."""
    import re as _re
    m = _re.match(r"^(\d+)(\D.*)?$", str(text))
    if not m or int(m.group(1)) == 0 or int(m.group(1)) > 999:
        return esc(text)
    n, rest = int(m.group(1)), m.group(2) or ""
    return f"<span class='count' style='--to:{n}'></span>{esc(rest)}"


def kpi_html(items):
    return "<div class='kpis'>" + "".join(
        f"<div class='kpi'><div class='l'>{l}</div><div class='v'>{countup(v)}</div><div class='h'>{h}</div></div>"
        for l, v, h in items) + "</div>"


FLOW_NODES = [("detector", "Detector", "ml"), ("log", "Log analysis", "llm"), ("rag", "Retrieval", "kb"),
              ("threat", "Threat analysis", "llm"), ("risk", "Risk", "llm"), ("report", "Report", "llm")]
LOOP_ICON = ("<svg viewBox='0 0 24 24' fill='none'><circle cx='12' cy='12' r='8' stroke='currentColor' "
             "stroke-width='2'/><path d='M17 4l3 3-3 3' stroke='currentColor' stroke-width='2' fill='none'/></svg>")


def flow_html(states, subs, loop_state, loop_text):
    """Live pipeline diagram: each node is pending, active or done; the evidence loop sits under Threat."""
    parts = []
    for i, (key, name, kind) in enumerate(FLOW_NODES):
        if i:
            lit = states.get(FLOW_NODES[i - 1][0]) == "done"
            parts.append(f"<div class='flink {'lit' if lit else ''}'>›</div>")
        st_ = states.get(key, "pending")
        parts.append(f"<div class='fnode {kind} {st_}'><div class='ft'>{name}</div>"
                     f"<div class='fs'>{esc(subs.get(key, '') or ('running' if st_ == 'active' else ''))}&nbsp;</div></div>")
    return ("<div class='flow'><div class='flow-row'>" + "".join(parts) + "</div>"
            f"<div class='floop'><div class='lp {loop_state}'>{LOOP_ICON}<span>Evidence loop · {esc(loop_text)}</span></div></div></div>")


def typewrite(placeholder, text, words_per_tick=7, delay=0.03):
    """Reveal the report a few words at a time, with a blinking caret."""
    words = text.split(" ")
    for i in range(0, len(words), words_per_tick):
        shown = " ".join(words[:i + words_per_tick])
        placeholder.markdown(f"<div class='report'>{esc(shown)}<span class='caret'></span></div>",
                             unsafe_allow_html=True)
        time.sleep(delay)
    placeholder.markdown(f"<div class='report'>{esc(text)}</div>", unsafe_allow_html=True)


CLASS_COLORS = {"BENIGN": "#22E3A3"}
ATTACK_SHADES = ["#FF4D6D", "#FF8A3D", "#FFC233", "#B36BFF", "#2CD5FF", "#5B8CFF"]


def breakdown_chart(breakdown, title):
    """Interactive donut of the detector breakdown; falls back to bars if plotly is missing."""
    try:
        import plotly.graph_objects as go
    except ImportError:
        st.markdown(f"<div class='evidence'><h3>{esc(title)}</h3>{breakdown_html(breakdown)}</div>",
                    unsafe_allow_html=True)
        return
    labels_ = [b["class"] for b in breakdown]
    values = [b["flows"] for b in breakdown]
    shade = iter(ATTACK_SHADES)
    colors = [CLASS_COLORS.get(c) or next(shade, "#FF4D6D") for c in labels_]
    hover = [f"<b>{esc(b['class'])}</b><br>{b['flows']} flows ({b['pct']}%)<br>mean confidence {b['mean_confidence']}"
             for b in breakdown]
    top = max(breakdown, key=lambda b: b["flows"])
    fig = go.Figure(go.Pie(
        labels=labels_, values=values, hole=0.62, sort=False, direction="clockwise",
        marker=dict(colors=colors, line=dict(color="#0A0F24", width=2)),
        text=hover, textinfo="none", hovertemplate="%{text}<extra></extra>"))
    fig.update_layout(
        height=300, margin=dict(l=10, r=10, t=36, b=10), paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)", font=dict(family="IBM Plex Sans, sans-serif", color="#F1F4FF", size=14),
        title=dict(text=title, font=dict(size=16, color="#F1F4FF"), x=0.02),
        legend=dict(orientation="v", x=1.0, y=0.5, font=dict(size=13, color="#A9B6E8")),
        annotations=[dict(text=f"<b>{top['pct']}%</b><br><span style='font-size:13px;color:#A9B6E8'>"
                               f"{esc(top['class'])}</span>",
                          x=0.5, y=0.5, showarrow=False, font=dict(size=24, color="#F1F4FF"))],
        hoverlabel=dict(bgcolor="#18224A", bordercolor="#2B3A73", font=dict(color="#F1F4FF")))
    st.plotly_chart(fig, use_container_width=True, config={"displayModeBar": False})


df = load_holdout()
metrics = load_metrics()
ev = load_evaluation()
labels = sorted(df["Label"].unique()) if df is not None else []


# ----------------------------------------------------------------------------
# Sidebar
# ----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("<div style='font-size:0.95rem;font-weight:600;margin-bottom:0.2rem'>Open a case</div>"
                "<div style='font-size:0.8rem;color:#A9B6E8;margin-bottom:1.1rem;line-height:1.5'>"
                "The system receives an unlabelled batch of network flows and must work out "
                "on its own whether it is an attack, and what kind. If it is unsure, it gathers "
                "more traffic before deciding.</div>", unsafe_allow_html=True)
    batch_size = st.slider("Flows in this incident", 100, 400, 200, step=50)
    run = st.button("Investigate a random incident")

    with st.expander("Demo controls"):
        st.markdown("<div style='font-size:0.78rem;color:#A9B6E8'>Pick a specific traffic type "
                    "instead of a random one. The agents still never see the label. Bot and "
                    "Web Attack often trigger evidence gathering.</div>", unsafe_allow_html=True)
        chosen = st.selectbox("Traffic type", labels) if labels else None
        seed = st.number_input("Sample seed", 0, 99999, 42)
        run_chosen = st.button("Investigate this type")

    st.markdown("<div style='margin-top:2rem;padding-top:1rem;border-top:1px solid #2B3A73;"
                "font-size:0.76rem;color:#7D8BC2;line-height:1.7'>Incidents are drawn from held-out "
                "flows across all five CICIDS2017 captures. The true label is revealed only after "
                "the verdict.</div>", unsafe_allow_html=True)


# ----------------------------------------------------------------------------
# Masthead
# ----------------------------------------------------------------------------
st.markdown("<div class='masthead'><div><h1>SOC Investigation Console</h1>"
            "<p class='sub'>Multi-agent triage across 10 attack types · CICIDS2017</p></div>"
            "<div class='status'><span class='dot'></span>Pipeline ready</div></div>",
            unsafe_allow_html=True)

strip = [
    ("Attack types detected", "10"),
    ("Detector flow accuracy", pct(metrics["report"]["accuracy"]) if metrics else "n/a"),
    ("Incident attack-type accuracy", pct(ev["type_acc"]) if ev else "n/a"),
    ("Incidents evaluated", str(ev["total"]) if ev else "n/a"),
]
st.markdown("<div class='strip'>" + "".join(
    f"<div><div class='l'>{l}</div><div class='v'>{countup(v)}</div></div>" for l, v in strip) + "</div>",
    unsafe_allow_html=True)

tab_case, tab_eval, tab_model, tab_limits, tab_about = st.tabs(
    ["Investigation", "Evaluation", "Detection model", "Limitations", "How it works"])


# ============================================================================
# TAB 1 - Investigation
# ============================================================================
with tab_case:
    if df is None:
        st.markdown("<div class='evidence bad'><h3>Held-out data not found</h3>"
                    "<p>Run <code>python train_multiclass.py</code> first.</p></div>",
                    unsafe_allow_html=True)
        st.stop()

    if run or run_chosen:
        backend = load_backend()
        P = backend["P"]
        if run:
            rng = random.Random(time.time_ns())
            label = rng.choice(labels)
            sample_seed = rng.randint(0, 99999)
            mode = "Blind (random)"
        else:
            label, sample_seed, mode = chosen, int(seed), "Demo (chosen type)"

        pool = df[df["Label"] == label]
        flows, extra = P.split_incident(pool, min(batch_size, len(pool)), sample_seed)
        alert_text, truth = P.build_incident(flows, label)
        detection = backend["score"](flows)
        case_id = f"CASE-{datetime.now():%Y%m%d-%H%M%S}"
        st.session_state.update({"alert_text": alert_text, "truth": truth, "case_id": case_id,
                                 "mode": mode})
        st.session_state.pop("result", None)

        st.markdown(f"<div class='sec'>{esc(case_id)} · {esc(mode)} · true label hidden</div>",
                    unsafe_allow_html=True)
        c1, c2 = st.columns([1.25, 1])
        with c1:
            rows = "".join(f"<div class='metric-row'><span class='label'>{esc(k)}</span>"
                           f"<span class='value'>{esc(v)}</span></div>" for k, v in parse_telemetry(alert_text))
            st.markdown(f"<div class='evidence'><h3>Telemetry</h3>{rows}</div>", unsafe_allow_html=True)
        with c2:
            breakdown_chart(detection["breakdown"], f"Detector breakdown · {detection['flows_analysed']} flows")

        st.markdown("<div class='sec'>Pipeline</div>", unsafe_allow_html=True)
        flow = st.empty()
        fstates = {"detector": "done"}
        fsubs = {"detector": f"{detection['pct_flagged']}% flagged"}
        floop = {"state": "", "text": "waiting for the Threat agent"}

        def draw_flow():
            flow.markdown(flow_html(fstates, fsubs, floop["state"], floop["text"]), unsafe_allow_html=True)

        draw_flow()

        st.markdown("<div class='sec'>Investigation chain</div>", unsafe_allow_html=True)
        spine = st.empty()
        chain = []                     # stages that have started: name, role, body, time, kind
        upcoming = list(BASE_STAGES)   # stages not yet reached

        def draw(active=None):
            html = ["<div class='spine'>"]
            for i, s in enumerate(chain):
                cls = "station active" if i == active else ("station loop" if s["kind"] == "loop" else "station done")
                if s["kind"] == "loop" and i == active:
                    cls = "station loop active"
                if i == len(chain) - 1:
                    cls += " fresh"
                t = f"<span class='t'>{s['t']:.1f}s</span>" if s["t"] is not None else ""
                html.append(f"<div class='{cls}'><div class='station-name'>{esc(s['name'])}{t}</div>"
                            f"<div class='station-role'>{esc(s['role'])}</div>")
                if s["body"]:
                    html.append(f"<div class='station-body'>{s['body']}</div>")
                html.append("</div>")
            for name, role in upcoming:
                html.append(f"<div class='station'><div class='station-name'>{esc(name)}</div>"
                            f"<div class='station-role'>{esc(role)}</div></div>")
            html.append("</div>")
            spine.markdown("".join(html), unsafe_allow_html=True)

        def stage(name, role, fn, s, kind="agent", base=True, node=None):
            if base and upcoming and upcoming[0][0] == name:
                upcoming.pop(0)
            chain.append({"name": name, "role": role, "body": "", "t": None, "kind": kind})
            if node == "loop":
                floop["state"] = "active"
                floop["text"] = f"gathering round {s.get('evidence_rounds', 0) + 1}"
            elif node:
                fstates[node] = "active"
            draw_flow()
            draw(active=len(chain) - 1)
            start = time.perf_counter()
            s = fn(s)
            chain[-1]["t"] = time.perf_counter() - start
            if node == "loop":
                n = s.get("evidence_rounds", 0)
                floop["state"] = "done"
                floop["text"] = f"{n} extra round{'s' if n != 1 else ''}"
            elif node:
                fstates[node] = "done"
            draw_flow()
            return s

        def threat_body(t):
            tech = (f"{esc(t.get('matched_technique_id'))} - {esc(t.get('matched_technique_name'))}"
                    if t.get("matched_technique_id") else "none")
            cav = t.get("caveats")
            cav_html = (f"<br><span class='k'>Caveats</span> <span class='cav'>{esc(cav)}</span>"
                        if cav and str(cav).lower() not in ("none", "null") else "")
            decision = ("<span class='cav'>gather more evidence</span>" if P.route_after_threat(state) == "gather"
                        else "<span class='ok'>evidence is sufficient, continue</span>")
            reason = t.get("evidence_reason")
            reason_html = f" <span class='v'>({esc(reason)})</span>" if reason else ""
            return (f"<span class='k'>Attack type</span> <span class='v'>{esc(t.get('attack_type') or 'none')}</span><br>"
                    f"<span class='k'>Technique</span> <span class='v'>{tech}</span><br>"
                    f"<span class='k'>Confidence</span> <span class='v'>{text_or_dash(t.get('confidence'))}</span><br>"
                    f"<span class='k'>Basis</span> <span class='v'>{esc(t.get('justification'))}</span>{cav_html}<br>"
                    f"<span class='k'>Decision</span> {decision}{reason_html}")

        state = {"alert_text": alert_text, "ground_truth": truth, "evidence_pool": extra}
        t0 = time.perf_counter()
        try:
            state = stage("Log Analysis", BASE_STAGES[0][1], P.log_analysis_agent, state, node="log")
            fsubs["log"] = state["log_findings"].get("attack_type") or state["log_findings"].get("assessment") or ""
            f = state["log_findings"]
            inds = f.get("suspicious_indicators") or []
            ind_html = ("<ul>" + "".join(f"<li>{esc(i)}</li>" for i in inds) + "</ul>") if inds else "<span class='v'>none</span>"
            chain[-1]["body"] = (f"<span class='k'>Assessment</span> <span class='v'>{esc(f.get('assessment'))}</span><br>"
                                 f"<span class='k'>Detected class</span> <span class='v'>{esc(f.get('attack_type') or 'none')}</span><br>"
                                 f"<span class='k'>Observed</span> <span class='v'>{esc(f.get('observed_behaviour'))}</span><br>"
                                 f"<span class='k'>Indicators</span> {ind_html}")

            state = stage("Knowledge Retrieval", BASE_STAGES[1][1], P.retrieve_techniques, state, node="rag")
            fsubs["rag"] = state["retrieved_techniques"][0]["id"] if state["retrieved_techniques"] else ""
            draw_flow()
            chain[-1]["body"] = "".join(f"<span class='tech {'hit' if k == 0 else ''}'>{esc(t['id'])} {esc(t['name'])}</span>"
                                        for k, t in enumerate(state["retrieved_techniques"]))

            state = stage("Threat Analysis", BASE_STAGES[2][1], P.threat_analysis_agent, state, node="threat")
            chain[-1]["body"] = threat_body(state["threat_assessment"])
            fsubs["threat"] = f"confidence {state['threat_assessment'].get('confidence') or '—'}"
            if P.route_after_threat(state) != "gather":
                floop["state"], floop["text"] = "skip", "not needed, evidence conclusive"
            draw_flow()

            # The agent's own decision: loop back for more evidence, or move on.
            while P.route_after_threat(state) == "gather":
                rnd = state.get("evidence_rounds", 0) + 1
                state = stage(f"Evidence gathering · round {rnd}",
                              "Fetches more traffic from the same source and runs the detector on it",
                              P.gather_evidence, state, kind="loop", base=False, node="loop")
                c = state["evidence_checks"][-1]
                result = {True: "<span class='ok'>confirms</span>", False: "<span class='no'>contradicts</span>",
                          None: "<span class='cav'>is inconclusive about</span>"}[c["agrees"]]
                chain[-1]["body"] = (f"<span class='k'>Extra flows examined</span> <span class='v'>{c['flows']}</span><br>"
                                     f"<span class='k'>Detector verdict</span> <span class='v'>{esc(c['verdict'])} "
                                     f"({c['pct_flagged']}% flagged)</span><br>"
                                     f"<span class='k'>Result</span> This batch {result} the original classification"
                                     f"{breakdown_html(c['breakdown'])}")
                fstates["threat"] = "active"
                draw_flow()
                state = stage("Threat Analysis · re-check",
                              "Re-assesses the case with the additional evidence",
                              P.threat_analysis_agent, state, base=False)
                fstates["threat"] = "done"
                fsubs["threat"] = f"confidence {state['threat_assessment'].get('confidence') or '—'}"
                draw_flow()
                chain[-1]["body"] = threat_body(state["threat_assessment"])

            state = stage("Risk Assessment", BASE_STAGES[3][1], P.risk_assessment_agent, state, node="risk")
            fsubs["risk"] = state["risk_assessment"].get("severity", "")
            draw_flow()
            r = state["risk_assessment"]
            sev = r.get("severity", "Informational")
            chain[-1]["body"] = (f"<span class='k'>Severity</span> <span class='chip {esc(sev)}'>{esc(sev)}</span><br>"
                                 f"<span class='k'>Impact</span> <span class='v'>{esc(r.get('impact'))}</span><br>"
                                 f"<span class='k'>Next step</span> <span class='v'>{esc(r.get('recommended_action'))}</span>")

            state = stage("Report Generation", BASE_STAGES[4][1], P.report_generation_agent, state, node="report")
            fsubs["report"] = "written"
            draw_flow()
            chain[-1]["body"] = "<span class='k'>Report written, shown below</span>"
            draw()
            st.session_state["result"] = state
            st.session_state["elapsed"] = time.perf_counter() - t0
        except Exception as exc:
            draw()
            msg = str(exc)
            if "429" in msg:
                msg = "The language model API rate limit was reached. Wait a minute and run the case again."
            st.markdown(f"<div class='evidence bad'><h3>Investigation stopped</h3><p>{esc(msg)}</p></div>",
                        unsafe_allow_html=True)
            st.stop()

    if "result" in st.session_state:
        state = st.session_state["result"]
        truth = st.session_state["truth"]
        f, t, r = state["log_findings"], state["threat_assessment"], state["risk_assessment"]
        is_attack = bool(t.get("is_attack"))
        predicted = f.get("attack_type") if is_attack else "BENIGN"
        correct = predicted == truth
        rounds = state.get("evidence_rounds", 0) or 0

        st.markdown(f"<div class='sec'>Verdict · completed in {st.session_state.get('elapsed', 0):.1f}s · "
                    f"{rounds} extra evidence round{'s' if rounds != 1 else ''}</div>", unsafe_allow_html=True)
        headline = f"Attack identified: {t.get('attack_type')}" if is_attack else "No attack identified"
        st.markdown(
            f"<div class='verdict {'threat' if is_attack else 'clear'}'>"
            f"<div><p class='headline'>{esc(headline)}</p><p class='detail'>{esc(r.get('justification'))}</p></div>"
            f"<div class='truth'>True label (revealed now)<span class='val {'match' if correct else 'miss'}'>"
            f"{esc(truth)} <span class='mark'>{'✓' if correct else '✗'}</span></span></div></div>", unsafe_allow_html=True)

        st.markdown("<div class='sec'>Incident report</div>", unsafe_allow_html=True)
        report_box = st.empty()
        if run or run_chosen:
            typewrite(report_box, state["final_report"])
        else:
            report_box.markdown(f"<div class='report'>{esc(state['final_report'])}</div>", unsafe_allow_html=True)
        cid = st.session_state.get("case_id", "case")
        st.download_button("Download report",
                           f"{cid}\nTrue label: {truth}\n\n{state['final_report']}\n\n--- Telemetry ---\n{st.session_state['alert_text']}\n",
                           file_name=f"{cid}.txt", mime="text/plain")
        with st.expander("Raw telemetry and agent output"):
            st.markdown(f"<div class='telemetry'>{esc(st.session_state['alert_text'])}</div>", unsafe_allow_html=True)
            checks = [{k: v for k, v in c.items() if k != "breakdown"} for c in (state.get("evidence_checks") or [])]
            st.json({"log_findings": f, "threat_assessment": t, "evidence_checks": checks, "risk_assessment": r})

    elif not (run or run_chosen):
        st.markdown("<div class='evidence'><h3>No case open</h3><p>Click <b>Investigate a random incident</b>. "
                    "The console draws unlabelled traffic, which could be any of 10 attack types or normal "
                    "traffic, and the agents must work out what it is. If the Threat agent is unsure, it "
                    "gathers more traffic from the same source before deciding. The true label is shown "
                    "only after the verdict.</p></div>", unsafe_allow_html=True)


# ============================================================================
# TAB 2 - Evaluation
# ============================================================================
with tab_eval:
    if ev is None:
        st.markdown("<div class='evidence'><h3>No evaluation results yet</h3>"
                    "<p>Run <code>python evaluate_multi.py</code>.</p></div>", unsafe_allow_html=True)
    else:
        st.markdown(f"<div class='lede'>Blind evaluation: {ev['total']} incidents of held-out flows, "
                    f"{ev['n_attack']} attack incidents across 10 attack types and {ev['n_benign']} benign "
                    f"incidents. The agents never see the label. {ev['gathered']} investigation"
                    f"{'s' if ev['gathered'] != 1 else ''} asked for more evidence "
                    f"({ev['extra_rounds']} extra round{'s' if ev['extra_rounds'] != 1 else ''} in total).</div>",
                    unsafe_allow_html=True)
        st.markdown(kpi_html([
            ("Attack vs normal", pct(ev["detect_acc"]), "incidents correctly flagged or cleared"),
            ("Attack type", pct(ev["attack_type_acc"]), f"of {ev['n_attack']} attack incidents"),
            ("False alarms", str(ev["false_alarms"]), f"of {ev['n_benign']} benign incidents"),
            ("Evidence gathered", str(ev["gathered"]), f"of {ev['total']} investigations"),
        ]), unsafe_allow_html=True)

        rows = ev["rows"]
        classes = sorted(set(rows["ground_truth"]) | set(rows["predicted_class"]))
        ct = pd.crosstab(rows["ground_truth"], rows["predicted_class"]).reindex(index=classes, columns=classes, fill_value=0)
        st.markdown("<div class='sec'>True vs predicted attack type</div>", unsafe_allow_html=True)
        head = "<tr><th></th>" + "".join(f"<th>{esc(c)}</th>" for c in classes) + "</tr>"
        body = ""
        for tr in classes:
            body += f"<tr><td class='rowh'>{esc(tr)}</td>"
            for pc in classes:
                n = int(ct.loc[tr, pc])
                bg = "rgba(34,227,163,0.25)" if (n and tr == pc) else ("rgba(255,77,109,0.3)" if n else "transparent")
                body += f"<td style='background:{bg}'>{n if n else ''}</td>"
            body += "</tr>"
        st.markdown(f"<div class='scroll'><table class='tbl heat'>{head}{body}</table></div>", unsafe_allow_html=True)

        st.markdown("<div class='sec'>Every incident</div>", unsafe_allow_html=True)
        body = ""
        for _, x in rows.iterrows():
            sev = x["severity"] if isinstance(x["severity"], str) else "n/a"
            tech = x["technique"] if isinstance(x["technique"], str) else "none"
            er = int(x["evidence_rounds"])
            body += (f"<tr><td class='mono'>{int(x['incident'])}</td><td>{esc(x['group'])}</td>"
                     f"<td>{esc(x['predicted_class'])}</td><td class='mono'>{esc(tech)}</td>"
                     f"<td>{text_or_dash(x['confidence'])}</td>"
                     f"<td class='mono {'warnc' if er else ''}'>{er if er else '—'}</td>"
                     f"<td><span class='chip {esc(sev)}'>{esc(sev)}</span></td>"
                     f"<td class='{'ok' if x['type_ok'] else 'no'}'>{'correct' if x['type_ok'] else 'missed'}</td></tr>")
        st.markdown("<div class='scroll'><table class='tbl'><tr><th>#</th><th>True traffic</th><th>Predicted</th>"
                    "<th>Technique</th><th>Confidence</th><th>Extra evidence</th><th>Severity</th><th>Result</th></tr>"
                    f"{body}</table></div>", unsafe_allow_html=True)


# ============================================================================
# TAB 3 - Detection model
# ============================================================================
with tab_model:
    if metrics is None:
        st.markdown("<div class='evidence'><h3>No detector metrics</h3>"
                    "<p>Run <code>python train_multiclass.py</code>.</p></div>", unsafe_allow_html=True)
    else:
        rep, classes = metrics["report"], metrics["classes"]
        st.markdown(f"<div class='lede'>A random forest classifies every flow into BENIGN or one of 10 attack "
                    f"types, using 74 flow features. Measured on {metrics['test_flows']:,} held-out flows.</div>",
                    unsafe_allow_html=True)
        st.markdown(kpi_html([
            ("Accuracy", pct(rep["accuracy"]), "all held-out flows"),
            ("Macro F1", f"{rep['macro avg']['f1-score']:.3f}", "average over 11 classes"),
            ("Classes", str(len(classes)), "BENIGN + 10 attack types"),
            ("Test flows", f"{metrics['test_flows']:,}", "never seen in training"),
        ]), unsafe_allow_html=True)

        st.markdown("<div class='sec'>Per-class results</div>", unsafe_allow_html=True)
        body = ""
        for c in classes:
            m = rep[c]
            pc = "warnc" if m["precision"] < 0.9 else ""
            body += (f"<tr><td>{esc(c)}</td><td class='mono {pc}'>{m['precision']:.3f}</td>"
                     f"<td class='mono'>{m['recall']:.3f}</td><td class='mono'>{m['f1-score']:.3f}</td>"
                     f"<td class='mono'>{int(m['support']):,}</td></tr>")
        st.markdown("<table class='tbl'><tr><th>Class</th><th>Precision</th><th>Recall</th><th>F1</th>"
                    f"<th>Test flows</th></tr>{body}</table>", unsafe_allow_html=True)

        st.markdown("<div class='sec'>Confusion matrix (rows = true, columns = predicted)</div>", unsafe_allow_html=True)
        cm = metrics["confusion_matrix"]
        short = [c.replace("DoS ", "").replace("-Patator", "") for c in classes]
        head = "<tr><th></th>" + "".join(f"<th>{esc(s)}</th>" for s in short) + "</tr>"
        body = ""
        for i, c in enumerate(classes):
            total = sum(cm[i]) or 1
            body += f"<tr><td class='rowh'>{esc(c)}</td>"
            for j, n in enumerate(cm[i]):
                a = n / total
                bg = f"rgba(34,227,163,{0.15 + 0.6 * a:.2f})" if i == j else (f"rgba(255,77,109,{min(0.6, 0.1 + a * 5):.2f})" if n else "transparent")
                body += f"<td style='background:{bg}'>{n if n else ''}</td>"
            body += "</tr>"
        st.markdown(f"<div class='scroll'><table class='tbl heat'>{head}{body}</table></div>", unsafe_allow_html=True)

        st.markdown("<div class='sec'>What the model keys on</div>", unsafe_allow_html=True)
        top = max(s for _, s in metrics["importances"]) or 1
        bars = "".join(f"<div class='bar-row'><span class='n'>{esc(n)}</span><div class='bar-track'>"
                       f"<div class='bar-fill' style='width:{100 * s / top:.0f}%;background:var(--agent)'></div></div>"
                       f"<span class='s'>{s:.3f}</span></div>" for n, s in metrics["importances"])
        st.markdown(f"<div class='evidence'>{bars}</div>", unsafe_allow_html=True)
        st.markdown("<div class='evidence warn'><h3>Features left out on purpose</h3><p>TCP window size and segment "
                    "size were excluded. They identify the sending machine rather than what the traffic did.</p></div>",
                    unsafe_allow_html=True)


# ============================================================================
# TAB 4 - Limitations
# ============================================================================
with tab_limits:
    st.markdown("<div class='lede'>Known limits of the current system, and what would address each.</div>",
                unsafe_allow_html=True)
    items = [
        ("Each incident contains one traffic type",
         "Real SOC traffic is mixed. Grouping flows by source IP and time window needs the CICIDS2017 "
         "version with IP addresses and timestamps, which is the next upgrade."),
        ("Extra evidence comes from the same traffic type",
         "This dataset version has no source IPs, so 'more traffic from the same source' is simulated as "
         "more held-out flows of the same traffic. With IP addresses it would be the same host's other "
         "connections."),
        ("Flow-level scores are optimistic",
         "The train/test split is random by flow, so flows from the same attack session can appear in both. "
         "The blind incident-level evaluation is the more honest measure."),
        ("Bot has low flow-level precision (0.342)",
         "Some benign flows are labelled Bot. At incident level this stays near 1% of flows, below the 5% "
         "threshold, so it does not cause false alarms."),
        ("The agents cannot change the detector's class",
         "The detector decides the attack class. The agents explain it, raise caveats, gather more evidence "
         "when unsure, and escalate to an analyst when new evidence contradicts the first batch."),
        ("Rare attacks were left out",
         "Infiltration (36 flows) and Heartbleed (11 flows) have too few examples to train or test honestly."),
        ("Evaluation sample is small",
         "About 2 incidents per attack type. More incidents per type would tighten the estimates."),
    ]
    for title, text in items:
        st.markdown(f"<div class='evidence warn'><h3>{esc(title)}</h3><p>{esc(text)}</p></div>",
                    unsafe_allow_html=True)


# ============================================================================
# TAB 5 - How it works
# ============================================================================
with tab_about:
    st.markdown("<div class='lede'>A security team receives far more alerts than it can investigate by hand. "
                "This console takes an unlabelled batch of network traffic and runs the investigation an "
                "analyst would: identify the attack type, map it to MITRE ATT&amp;CK, gather more evidence "
                "when unsure, rate the risk and write the report.</div>", unsafe_allow_html=True)
    nodes = [("ml", "Multi-class detector", "Random forest, 11 classes, scores every flow"),
             ("llm", "Log analysis", "Reads telemetry and the detector breakdown"),
             ("kb", "Knowledge retrieval", "Class-mapped MITRE techniques + keyword search"),
             ("llm", "Threat analysis", "Explains the attack type, raises caveats, decides next step"),
             ("llm", "Risk assessment", "Severity and next step"),
             ("llm", "Report generation", "Analyst-ready incident report")]
    parts = []
    for i, (k, tt, d) in enumerate(nodes):
        if i:
            parts.append("<div class='arrow'>›</div>")
        parts.append(f"<div class='node {k}'><div class='t'>{tt}</div><div class='d'>{d}</div></div>")
    st.markdown("<div class='sec'>Pipeline</div><div class='arch'>" + "".join(parts) + "</div>"
                "<div class='loopnote'>↺ Evidence loop: when the Threat agent is not confident, it fetches more "
                "traffic from the same source, runs the detector on it and re-checks, up to 2 extra rounds. "
                "If the new traffic contradicts the first batch, the case is escalated to an analyst.</div>",
                unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    with c1:
        st.markdown("<div class='sec'>Division of roles</div><div class='evidence'>"
                    "<p><b style='color:#F1F4FF'>The detector decides the attack class.</b> It uses 74 features "
                    "per flow and is far more reliable than reasoning from summary statistics.</p>"
                    "<p><b style='color:#F1F4FF'>The agents investigate.</b> They explain the evidence, map it to "
                    "MITRE ATT&amp;CK, flag anything unusual, decide whether more evidence is needed, assess risk "
                    "and write the report.</p></div>", unsafe_allow_html=True)
    with c2:
        st.markdown("<div class='sec'>Data</div><div class='evidence'>"
                    "<div class='metric-row'><span class='label'>Dataset</span><span class='value'>CICIDS2017, Mon–Fri</span></div>"
                    "<div class='metric-row'><span class='label'>Attack types</span><span class='value'>10</span></div>"
                    "<div class='metric-row'><span class='label'>MITRE techniques</span><span class='value'>10</span></div>"
                    "<div class='metric-row'><span class='label'>Orchestration</span><span class='value'>LangGraph (conditional loop)</span></div>"
                    "<div class='metric-row'><span class='label'>LLM</span><span class='value'>gpt-oss-120b via Groq</span></div>"
                    "</div>", unsafe_allow_html=True)