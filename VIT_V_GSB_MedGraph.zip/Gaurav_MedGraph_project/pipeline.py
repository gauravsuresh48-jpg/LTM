import os
import re
import json
import time
import pandas as pd
from typing import TypedDict, List, Any
from dotenv import load_dotenv
from groq import Groq
from langgraph.graph import StateGraph, END

from build_kb import retrieve, CLASS_TO_TECHNIQUES, BY_ID
from baseline import compute_baselines, format_baseline
from detector_multi import score_flows, describe_detection

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))
MODEL = "openai/gpt-oss-120b"
print("Loading traffic baselines from attack-free capture...")
BASELINES = compute_baselines()

# Evidence gathering: how much extra traffic one round fetches, and the limits.
EVIDENCE_BATCH = 200
MIN_EVIDENCE_FLOWS = 50
MAX_EVIDENCE_ROUNDS = 2
CONFLICT_MSG = ("Additional traffic from the same source does not match the original "
                "classification; analyst review recommended.")


# ---------- Shared state passed between agents ----------
class IncidentState(TypedDict, total=False):
    alert_text: str
    ground_truth: str
    log_findings: dict
    retrieved_techniques: List[dict]
    threat_assessment: dict
    risk_assessment: dict
    final_report: str
    evidence_pool: Any          # more flows from the same traffic source (DataFrame) or None
    evidence_rounds: int        # how many extra batches have been fetched
    evidence_checks: List[dict] # result of each extra batch
    extra_evidence: List[str]   # detector output for each extra batch, as text


RETRYABLE = ("429", "connection", "timeout", "timed out", "500", "502", "503", "504")


def call_llm(system_prompt, user_content, max_retries=5):
    for attempt in range(max_retries):
        try:
            response = client.chat.completions.create(
                model=MODEL,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_content}
                ],
                temperature=0
            )
            raw = response.choices[0].message.content.strip()
            return raw.replace("```json", "").replace("```", "").strip()
        except Exception as e:
            msg = str(e).lower()
            if any(code in msg for code in RETRYABLE) and attempt < max_retries - 1:
                wait = 20 * (attempt + 1)
                print(f"      API problem ({str(e)[:40]}), retrying in {wait}s...")
                time.sleep(wait)
                continue
            raise


# ---------- Attack-class helpers ----------
CANONICAL = {c.lower(): c for c in CLASS_TO_TECHNIQUES}

PLAIN_NAMES = {
    "FTP-Patator": "FTP brute force (password guessing)",
    "SSH-Patator": "SSH brute force (password guessing)",
    "DoS Hulk": "HTTP flood denial of service (Hulk)",
    "DoS GoldenEye": "HTTP keep-alive denial of service (GoldenEye)",
    "DoS slowloris": "Slow HTTP denial of service (slowloris)",
    "DoS Slowhttptest": "Slow HTTP denial of service (Slowhttptest)",
    "DDoS": "Distributed denial of service (DDoS)",
    "PortScan": "Port scan (network reconnaissance)",
    "Web Attack": "Web application attack (brute force / XSS / SQL injection)",
    "Bot": "Botnet command-and-control traffic",
}


def detector_top_attack(alert_text):
    """Read the detector's most common attack class straight from the incident text."""
    for line in alert_text.splitlines():
        m = re.match(r"\s*-\s*(.+?):\s*\d+ flows", line)
        if m and m.group(1).strip() != "BENIGN":
            return m.group(1).strip()
    return None


def detector_pct(alert_text):
    """Share of flows the detector assigned to an attack class, from the incident text."""
    m = re.search(r"Flows classified as an attack type:\s*([\d.]+)%", alert_text)
    return float(m.group(1)) if m else 0.0


def canonical_class(agent_value, alert_text):
    """Map the agent's attack_type to a known class; fall back to the detector."""
    if agent_value:
        key = agent_value.strip().lower()
        if key in CANONICAL:
            return CANONICAL[key]
        for k, v in CANONICAL.items():
            if k in key or key in k:
                return v
    return detector_top_attack(alert_text)


CONF_RANK = {"low": 0, "medium": 1, "high": 2}


def has_caveat(t):
    c = t.get("caveats")
    return bool(c) and str(c).strip().lower() not in ("none", "null", "")


# ---------- Evidence-gathering helpers ----------
def evidence_remaining(state):
    pool = state.get("evidence_pool")
    if pool is None:
        return 0
    return max(0, len(pool) - state.get("evidence_rounds", 0) * EVIDENCE_BATCH)


def more_evidence_available(state):
    return (state.get("evidence_rounds", 0) < MAX_EVIDENCE_ROUNDS
            and evidence_remaining(state) >= MIN_EVIDENCE_FLOWS)


def batch_verdict(detection):
    """Apply the same thresholds as the Log Analysis Agent to one extra batch."""
    if detection["pct_flagged"] > 20:
        return detection["dominant_attack"]
    if detection["pct_flagged"] < 5:
        return "BENIGN"
    return "UNCLEAR"


def evidence_summary(state):
    checks = state.get("evidence_checks") or []
    if not checks:
        return "No additional evidence was gathered; the first batch was conclusive."
    parts = []
    for c in checks:
        result = {True: "confirms", False: "CONTRADICTS", None: "is inconclusive about"}[c["agrees"]]
        parts.append(f"Round {c['round']}: {c['flows']} more flows, detector verdict "
                     f"{c['verdict']} ({c['pct_flagged']}% flagged), which {result} the original classification.")
    return "\n".join(parts)


# ---------- AGENT 1: Log Analysis ----------
LOG_PROMPT = """You are a Log Analysis Agent in a security operations pipeline.

You receive a network activity report for one incident (a batch of network
flows). It includes output from a trained multi-class detector that assigns
each flow to BENIGN or to a specific attack type. The detector was fitted on
labelled historical traffic and is the authoritative signal.

Use this rule on "Flows classified as an attack type":
- More than 20%: the activity is suspicious.
- Less than 5%: the activity is normal, regardless of how the raw traffic
  statistics look to you.
- Between those figures: suspicious only if a single attack type accounts for
  most of the flagged flows with mean confidence above 0.8; otherwise normal.

When the activity is suspicious, the attack type is the predicted class with
the most flows. Copy its name exactly as written in the detector breakdown.
Treat a few flows of other attack classes as minor noise.

Describe the traffic using the actual figures. Only call payload "low" or
sessions "short" if the numbers show it.

Return ONLY valid JSON with these keys:
- service: the service or protocol involved
- connection_count: number of connections observed
- observed_behaviour: one sentence describing the traffic pattern, quoting exact figures
- suspicious_indicators: list of specific anomalies found (empty list if none)
- assessment: one of "suspicious" or "normal"
- attack_type: the dominant predicted attack class if suspicious, otherwise null
- reasoning: one sentence explaining the assessment, citing the detector output

No markdown, no text outside the JSON."""


def log_analysis_agent(state: IncidentState) -> IncidentState:
    print("  [Agent 1] Log Analysis Agent running...")
    service = state["alert_text"].split("Service: ")[1].split(" ")[0]
    if service in ("HTTP", "HTTPS"):
        baseline_text = format_baseline(service, BASELINES)
    else:
        baseline_text = "No reliable historical baseline is available for this service."

    content = f"{state['alert_text']}\n\n{baseline_text}"
    findings = json.loads(call_llm(LOG_PROMPT, content))
    if findings.get("assessment") == "suspicious":
        findings["attack_type"] = canonical_class(findings.get("attack_type"), state["alert_text"])
    else:
        findings["attack_type"] = None
    state["log_findings"] = findings
    return state


# ---------- RETRIEVAL STEP: pull relevant MITRE techniques ----------
def retrieve_techniques(state: IncidentState) -> IncidentState:
    print("  [RAG] Retrieving MITRE ATT&CK techniques...")
    f = state["log_findings"]
    predicted = f.get("attack_type")
    query = (
        f"{f.get('service', '')} {f.get('observed_behaviour', '')} "
        f"{' '.join(f.get('suspicious_indicators', []))} {predicted or ''}"
    )
    state["retrieved_techniques"] = retrieve(predicted, query, n_results=3)
    return state


# ---------- AGENT 2: Threat Analysis ----------
THREAT_PROMPT = """You are a Threat Analysis Agent in a security operations pipeline.

You receive findings from a Log Analysis Agent, the attack classification
decided by a validated multi-class detector, MITRE ATT&CK techniques from a
knowledge base, and possibly ADDITIONAL EVIDENCE: extra batches of traffic from
the same source that you asked for in an earlier round.

If the activity was assessed as normal: return null for attack_type and the
technique fields, and false for is_attack.

If the activity was assessed as suspicious: the attack class and its MITRE
technique are ALREADY DECIDED (shown as DECIDED CLASSIFICATION). The detector
classifies each flow using 74 traffic features and is far more reliable than
reasoning from summary statistics, so do not change the classification.
Your job is to:
1. Explain which evidence supports this classification, quoting exact figures
   (service and port, distinct destination ports, session duration, payload,
   and the detector's share of flows and confidence).
2. List in "caveats" any evidence that looks unusual for this attack type, so
   an analyst can double-check it. Use null if nothing looks unusual.
3. Set confidence: "high" if the detected class covers more than 80% of flows
   with mean confidence above 0.8 and there are no major caveats; "medium"
   otherwise; "low" if the class covers less than half of the flows.

Deciding whether to gather more evidence (needs_more_evidence):
- Set it to true when you are not confident: your confidence is not "high", or
  you listed caveats, or (for normal activity) the detector flagged 5% or more
  of flows. Only do this if the INVESTIGATION STATUS says more traffic is available.
- Set it to false when the evidence is already conclusive.
- When ADDITIONAL EVIDENCE is present and every extra batch confirms the
  classification, treat that as strong support: raise confidence to "high"
  and drop caveats that the extra traffic resolves.

Do not estimate, round, or convert units. Only call payload "low" or sessions
"short" if the figures show it.

Return ONLY valid JSON with these keys:
- attack_type: copy the decided attack name, or null
- matched_technique_id: copy the decided technique ID, or null
- matched_technique_name: copy the decided technique name, or null
- confidence: one of "high", "medium", "low"
- justification: one or two sentences citing the specific evidence
- caveats: one sentence on anything unusual, or null
- needs_more_evidence: true or false
- evidence_reason: one short sentence explaining that decision
- is_attack: true or false

No markdown, no text outside the JSON."""


def threat_analysis_agent(state: IncidentState) -> IncidentState:
    rounds = state.get("evidence_rounds", 0)
    print(f"  [Agent 2] Threat Analysis Agent running{' (re-check)' if rounds else ''}...")
    previous_confidence = (state.get("threat_assessment") or {}).get("confidence") if rounds else None
    f = state["log_findings"]
    cls = f.get("attack_type")
    suspicious = f.get("assessment") == "suspicious" and cls in CLASS_TO_TECHNIQUES

    if suspicious:
        tech_id = CLASS_TO_TECHNIQUES[cls][0]
        decided = (f"Attack class: {cls}\nAttack name: {PLAIN_NAMES[cls]}\n"
                   f"Technique: {tech_id} - {BY_ID[tech_id]['name']}")
    else:
        decided = "None - the activity was assessed as normal."

    techniques_text = "\n\n".join(
        f"{t['id']} - {t['name']}\n{t['text']}" for t in state["retrieved_techniques"]
    )
    extra = state.get("extra_evidence") or []
    status = (f"Additional evidence rounds used: {rounds} of {MAX_EVIDENCE_ROUNDS}. "
              f"More traffic available from this source: {'yes' if more_evidence_available(state) else 'no'}.")
    content = (
        f"ORIGINAL ALERT:\n{state['alert_text']}\n\n"
        f"LOG ANALYSIS FINDINGS:\n{json.dumps(f, indent=2)}\n\n"
        f"DECIDED CLASSIFICATION:\n{decided}\n\n"
        f"KNOWLEDGE BASE TECHNIQUES:\n{techniques_text}\n\n"
        f"INVESTIGATION STATUS:\n{status}\n\n"
        f"ADDITIONAL EVIDENCE:\n" + ("\n\n".join(extra) if extra else "None gathered yet.")
    )
    t = json.loads(call_llm(THREAT_PROMPT, content))

    # Safety net: the classification always follows the detector and the KB mapping.
    if suspicious:
        t["attack_type"] = PLAIN_NAMES[cls]
        t["matched_technique_id"] = tech_id
        t["matched_technique_name"] = BY_ID[tech_id]["name"]
        t["is_attack"] = True
    else:
        t.update(attack_type=None, matched_technique_id=None,
                 matched_technique_name=None, is_attack=False)
        if not has_caveat(t):
            t["caveats"] = None

    # Guardrails on the agent's decision to keep investigating.
    t["needs_more_evidence"] = bool(t.get("needs_more_evidence"))
    if t.get("confidence") == "high" and not has_caveat(t):
        t["needs_more_evidence"] = False
    if not suspicious and detector_pct(state["alert_text"]) < 5:
        t["needs_more_evidence"] = False

    checks = state.get("evidence_checks") or []
    # Confirming evidence must never lower confidence: if every extra batch agreed,
    # keep at least the confidence the agent had before this round.
    if checks and all(c["agrees"] is True for c in checks) and previous_confidence in CONF_RANK:
        if CONF_RANK.get(t.get("confidence"), -1) < CONF_RANK[previous_confidence]:
            t["confidence"] = previous_confidence

    if any(c["agrees"] is False for c in checks):
        t["confidence"] = "low"
        t["caveats"] = CONFLICT_MSG
        t["needs_more_evidence"] = False   # conflict found: escalate to an analyst
        t["evidence_reason"] = "Extra traffic contradicts the first batch, so the case goes to an analyst."

    state["threat_assessment"] = t
    return state


# ---------- EVIDENCE GATHERING ----------
def gather_evidence(state: IncidentState) -> IncidentState:
    """Fetch the next batch of traffic from the same source and run the detector on it."""
    k = state.get("evidence_rounds", 0)
    print(f"  [Evidence] Gathering round {k + 1}: fetching more traffic from the same source...")
    pool = state["evidence_pool"]
    batch = pool.iloc[k * EVIDENCE_BATCH:(k + 1) * EVIDENCE_BATCH]
    det = score_flows(batch)

    f = state["log_findings"]
    original = f.get("attack_type") if f.get("assessment") == "suspicious" else "BENIGN"
    verdict = batch_verdict(det)
    agrees = None if verdict == "UNCLEAR" else (verdict == original)

    checks = list(state.get("evidence_checks") or [])
    checks.append({"round": k + 1, "flows": len(batch), "verdict": verdict,
                   "pct_flagged": det["pct_flagged"], "agrees": agrees,
                   "breakdown": det["breakdown"]})
    word = {True: "AGREES with", False: "DISAGREES with", None: "is inconclusive about"}[agrees]
    text = (f"Additional evidence, round {k + 1} ({len(batch)} more flows from the same source):\n"
            f"{describe_detection(det)}\n"
            f"Consistency check: this batch's verdict is {verdict}, which {word} the "
            f"original classification ({original}).")

    state["evidence_checks"] = checks
    state["extra_evidence"] = list(state.get("extra_evidence") or []) + [text]
    state["evidence_rounds"] = k + 1
    return state


def route_after_threat(state: IncidentState) -> str:
    """Conditional edge: gather more evidence, or move on to risk assessment."""
    t = state["threat_assessment"]
    if t.get("needs_more_evidence") and more_evidence_available(state):
        return "gather"
    return "assess"


# ---------- AGENT 3: Risk Assessment ----------
RISK_PROMPT = """You are a Risk Assessment Agent in a security operations pipeline.

You receive log findings, a threat assessment, and a summary of any additional
evidence the investigation gathered. Assign a severity level.

Severity guidance:
- High: confirmed attack that can grant access or take a service down, with
  high confidence. This covers credential brute force, denial of service and
  distributed denial of service, web application exploitation, and botnet
  command-and-control.
- Medium: confirmed reconnaissance such as a port scan, or any attack with
  medium or low confidence.
- Low: minor anomaly with no confirmed technique.
- Informational: activity appears normal.

If the additional evidence contradicts the classification, recommend that an
analyst reviews the case manually.

Return ONLY valid JSON with these keys:
- severity: one of "High", "Medium", "Low", "Informational"
- impact: one sentence on what could happen if this is a real attack
- recommended_action: one sentence on what an analyst should do next
- justification: one sentence explaining the severity choice

No markdown, no text outside the JSON."""


def risk_assessment_agent(state: IncidentState) -> IncidentState:
    print("  [Agent 3] Risk Assessment Agent running...")
    content = (
        f"LOG FINDINGS:\n{json.dumps(state['log_findings'], indent=2)}\n\n"
        f"THREAT ASSESSMENT:\n{json.dumps(state['threat_assessment'], indent=2)}\n\n"
        f"ADDITIONAL EVIDENCE GATHERED:\n{evidence_summary(state)}"
    )
    state["risk_assessment"] = json.loads(call_llm(RISK_PROMPT, content))
    return state


# ---------- AGENT 4: Report Generation ----------
REPORT_PROMPT = """You are a Report Generation Agent in a security operations pipeline.

You receive the complete findings of an investigation. Write a concise incident
report for a security analyst.

Use exactly this structure with these headings:
INCIDENT SUMMARY
TECHNICAL FINDINGS
THREAT CLASSIFICATION
RISK AND IMPACT
RECOMMENDED ACTIONS

Under TECHNICAL FINDINGS, if additional evidence was gathered, say how many
extra flows were examined and whether they confirmed the classification.
Under THREAT CLASSIFICATION, state the attack type and the MITRE technique,
and mention any caveats from the threat assessment.
Use only information present in the input. Do not add dates, IP addresses,
hostnames, or placeholders such as "[date not provided]".

Keep it factual and under 240 words. Plain text only, no markdown."""


def report_generation_agent(state: IncidentState) -> IncidentState:
    print("  [Agent 4] Report Generation Agent running...")
    content = (
        f"ORIGINAL ALERT:\n{state['alert_text']}\n\n"
        f"LOG FINDINGS:\n{json.dumps(state['log_findings'], indent=2)}\n\n"
        f"THREAT ASSESSMENT:\n{json.dumps(state['threat_assessment'], indent=2)}\n\n"
        f"ADDITIONAL EVIDENCE GATHERED:\n{evidence_summary(state)}\n\n"
        f"RISK ASSESSMENT:\n{json.dumps(state['risk_assessment'], indent=2)}"
    )
    state["final_report"] = call_llm(REPORT_PROMPT, content)
    return state


# ---------- Build the LangGraph pipeline ----------
def build_pipeline():
    graph = StateGraph(IncidentState)
    graph.add_node("log_analysis", log_analysis_agent)
    graph.add_node("retrieve", retrieve_techniques)
    graph.add_node("threat_analysis", threat_analysis_agent)
    graph.add_node("gather_evidence", gather_evidence)
    graph.add_node("risk_assessment", risk_assessment_agent)
    graph.add_node("report_generation", report_generation_agent)

    graph.set_entry_point("log_analysis")
    graph.add_edge("log_analysis", "retrieve")
    graph.add_edge("retrieve", "threat_analysis")
    # The Threat agent decides: gather more evidence (loop back) or move on.
    graph.add_conditional_edges("threat_analysis", route_after_threat,
                                {"gather": "gather_evidence", "assess": "risk_assessment"})
    graph.add_edge("gather_evidence", "threat_analysis")
    graph.add_edge("risk_assessment", "report_generation")
    graph.add_edge("report_generation", END)
    return graph.compile()


# ---------- Incident builder ----------
SERVICE = {21: "FTP", 22: "SSH", 80: "HTTP", 443: "HTTPS", 8080: "HTTP-alt",
           139: "NetBIOS", 445: "SMB", 53: "DNS"}
MULTI_PORT_THRESHOLD = 20


def build_incident(flows, label):
    """Summarise a batch of flows as an alert. The label is NOT included in the text."""
    port = int(flows["Destination Port"].mode()[0])
    distinct_ports = int(flows["Destination Port"].nunique())
    n = len(flows)

    # When traffic is spread across many ports, no single port describes it.
    if distinct_ports > MULTI_PORT_THRESHOLD:
        service_line = f"MULTI-PORT (connections spread across {distinct_ports} destination ports)"
    else:
        service_line = f"{SERVICE.get(port, f'port-{port}')} (most common destination port {port})"

    med_dur_ms = flows["Flow Duration"].median() / 1000
    med_fwd_payload = flows["Total Length of Fwd Packets"].median()
    med_fwd_pkts = flows["Total Fwd Packets"].median()
    med_bwd_pkts = flows["Total Backward Packets"].median()
    zero_payload_pct = (flows["Total Length of Fwd Packets"] == 0).mean() * 100

    detection = score_flows(flows)

    text = (
        f"Network Activity Report\n"
        f"Service: {service_line}\n"
        f"Connections observed: {n}\n"
        f"Distinct destination ports: {distinct_ports}\n"
        f"Median session duration: {med_dur_ms:.1f} ms ({med_dur_ms / 1000:.2f} seconds)\n"
        f"Median forward payload per connection: {med_fwd_payload:.0f} bytes\n"
        f"Connections carrying zero payload: {zero_payload_pct:.0f}%\n"
        f"Median forward packets per connection: {med_fwd_pkts:.0f}\n"
        f"Median backward packets per connection: {med_bwd_pkts:.0f}\n"
        f"\n"
        f"{describe_detection(detection)}"
    )
    return text, label


def split_incident(pool, n_flows, seed):
    """Shuffle one traffic source: the first n_flows form the incident, the rest is extra evidence."""
    shuffled = pool.sample(frac=1, random_state=seed)
    return shuffled.iloc[:n_flows], shuffled.iloc[n_flows:].reset_index(drop=True)


if __name__ == "__main__":
    print("=" * 72)
    print("MULTI-AGENT INVESTIGATION - BLIND TEST WITH EVIDENCE GATHERING")
    print("=" * 72)

    df = pd.read_csv("data/holdout_multi.csv")
    pipeline = build_pipeline()

    for truth in ["Bot", "Web Attack", "PortScan"]:
        flows, extra = split_incident(df[df["Label"] == truth], 200, seed=7)
        alert_text, label = build_incident(flows, truth)

        print("\n" + "=" * 72)
        print("NEW INCIDENT (label hidden from the agents)")
        print("=" * 72)
        result = pipeline.invoke({"alert_text": alert_text, "ground_truth": label,
                                  "evidence_pool": extra})
        t, r = result["threat_assessment"], result["risk_assessment"]

        print("\n--- VERDICT ---")
        print(f"Attack type      : {t.get('attack_type')}")
        print(f"Technique        : {t.get('matched_technique_id')} {t.get('matched_technique_name') or ''}")
        print(f"Confidence       : {t.get('confidence')}")
        print(f"Severity         : {r.get('severity')}")
        print(f"Caveats          : {t.get('caveats')}")
        print(f"Evidence rounds  : {result.get('evidence_rounds', 0)}")
        print(f"Evidence summary : {evidence_summary(result)}")
        print(f"\nTRUE LABEL       : {label}")
        time.sleep(10)

    print("\n" + "=" * 72)
    print("BLIND TEST COMPLETE")
    print("=" * 72)