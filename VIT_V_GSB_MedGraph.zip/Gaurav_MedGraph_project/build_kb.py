"""
MITRE ATT&CK knowledge base for the Threat Analysis Agent.

Retrieval combines two signals:
  1. A direct mapping from the detector's predicted attack class to techniques.
  2. Keyword overlap with the Log Analysis Agent's findings.
"""

TECHNIQUES = [
    {
        "id": "T1110",
        "name": "Brute Force",
        "keywords": ["repeated", "failed", "authentication", "login", "password",
                     "many connections", "low payload", "short session"],
        "text": (
            "Brute Force. Adversaries try many credentials to gain access when passwords "
            "are unknown. This produces many repeated authentication attempts in a short "
            "period, with small payloads because sessions end after each failed login."
        ),
    },
    {
        "id": "T1110.001",
        "name": "Password Guessing",
        "keywords": ["ssh", "ftp", "port 22", "port 21", "telnet", "rdp",
                     "guessing", "credentials", "lockout", "patator"],
        "text": (
            "Password Guessing. Adversaries guess passwords against login services such "
            "as SSH on port 22 and FTP on port 21. A high volume of connections to one of "
            "these services with low payload per connection is a strong indicator."
        ),
    },
    {
        "id": "T1110.003",
        "name": "Password Spraying",
        "keywords": ["spraying", "multiple accounts", "common passwords", "lockout"],
        "text": (
            "Password Spraying. Adversaries try a few common passwords against many "
            "accounts to avoid lockouts. Attempts are spread across accounts rather than "
            "concentrated on one."
        ),
    },
    {
        "id": "T1078",
        "name": "Valid Accounts",
        "keywords": ["valid", "legitimate", "normal session", "successful login",
                     "typical payload"],
        "text": (
            "Valid Accounts. Adversaries abuse real credentials. Sessions look normal, "
            "with typical data volumes, which makes detection harder."
        ),
    },
    {
        "id": "T1046",
        "name": "Network Service Discovery",
        "keywords": ["scan", "scanning", "discovery", "multiple ports", "port scan",
                     "portscan", "very short", "no payload", "distinct ports"],
        "text": (
            "Network Service Discovery. Adversaries probe hosts to list running services. "
            "This produces many very short connections across many different destination "
            "ports, with almost no payload, since the goal is only to see which ports are open."
        ),
    },
    {
        "id": "T1499",
        "name": "Endpoint Denial of Service",
        "keywords": ["denial of service", "dos", "flood", "high volume",
                     "availability", "sustained"],
        "text": (
            "Endpoint Denial of Service. Adversaries degrade or block the availability of a "
            "service on a single host by overwhelming it with requests or connections."
        ),
    },
    {
        "id": "T1499.002",
        "name": "Service Exhaustion Flood",
        "keywords": ["http", "web server", "port 80", "slowloris", "slow", "held open",
                     "hulk", "goldeneye", "slowhttptest", "exhaustion", "keep-alive"],
        "text": (
            "Service Exhaustion Flood. Adversaries target a specific service such as a web "
            "server. This includes HTTP floods that send large numbers of requests, and slow "
            "attacks such as slowloris that hold many connections open with very little data "
            "until the server runs out of connection slots."
        ),
    },
    {
        "id": "T1498",
        "name": "Network Denial of Service",
        "keywords": ["ddos", "distributed", "network flood", "bandwidth", "many sources",
                     "volumetric"],
        "text": (
            "Network Denial of Service. Adversaries, often from many machines at once, send "
            "so much traffic that the target's network or service capacity is exhausted. "
            "Distributed attacks show a very high, sustained volume of traffic to one target."
        ),
    },
    {
        "id": "T1190",
        "name": "Exploit Public-Facing Application",
        "keywords": ["web attack", "sql injection", "xss", "cross-site", "web application",
                     "http", "port 80", "injection", "exploit"],
        "text": (
            "Exploit Public-Facing Application. Adversaries exploit weaknesses in internet-"
            "facing applications such as websites, using techniques like SQL injection, "
            "cross-site scripting, or brute-forcing a web login form."
        ),
    },
    {
        "id": "T1071.001",
        "name": "Application Layer Protocol: Web Protocols",
        "keywords": ["bot", "botnet", "command and control", "c2", "beacon", "periodic",
                     "infected", "http"],
        "text": (
            "Web Protocols for Command and Control. Infected machines (bots) communicate "
            "with an attacker's server over normal web traffic to receive commands. This "
            "appears as regular, repeated connections that blend in with ordinary browsing."
        ),
    },
]

BY_ID = {t["id"]: t for t in TECHNIQUES}

# Detector class -> techniques, most specific first.
CLASS_TO_TECHNIQUES = {
    "FTP-Patator": ["T1110.001", "T1110"],
    "SSH-Patator": ["T1110.001", "T1110"],
    "DoS Hulk": ["T1499.002", "T1499"],
    "DoS GoldenEye": ["T1499.002", "T1499"],
    "DoS slowloris": ["T1499.002", "T1499"],
    "DoS Slowhttptest": ["T1499.002", "T1499"],
    "DDoS": ["T1498", "T1499"],
    "PortScan": ["T1046"],
    "Web Attack": ["T1190", "T1110"],
    "Bot": ["T1071.001"],
}


def search_kb(query, n_results=3):
    """Score techniques by keyword overlap with the query."""
    q_words = set(query.lower().replace(",", " ").replace("(", " ").replace(")", " ").split())
    scored = []
    for t in TECHNIQUES:
        score = 0
        for kw in t["keywords"]:
            kw_words = set(kw.lower().split())
            overlap = len(kw_words & q_words)
            if overlap == len(kw_words):
                score += 2
            elif overlap > 0:
                score += 0.5
        if score > 0:
            scored.append((score, t))
    scored.sort(key=lambda x: x[0], reverse=True)
    if not scored:
        return TECHNIQUES[:n_results]
    return [t for _, t in scored[:n_results]]


def retrieve(predicted_class, query, n_results=3):
    """Techniques mapped to the detector's class first, then keyword matches."""
    results = [BY_ID[i] for i in CLASS_TO_TECHNIQUES.get(predicted_class, [])]
    for t in search_kb(query, n_results=n_results + len(results)):
        if t not in results:
            results.append(t)
    return results[:n_results]


if __name__ == "__main__":
    print(f"Knowledge base loaded: {len(TECHNIQUES)} MITRE ATT&CK techniques\n")
    tests = [
        ("DoS slowloris", "HTTP port 80 many connections held open with little data"),
        ("PortScan", "very short connections across many distinct ports"),
        ("SSH-Patator", "SSH port 22 repeated login attempts"),
        (None, "normal web browsing typical payload"),
    ]
    for cls, q in tests:
        print(f"Class: {cls}  |  Query: {q}")
        for t in retrieve(cls, q):
            print(f"    {t['id']:<10} {t['name']}")
        print()