"""
Blind evaluation of the multi-agent pipeline across all attack types.
Each incident is 200 held-out flows; the label is never shown to the agents.
When the Threat agent is not confident it can gather more traffic from the same
source (flows from the same group that are not part of any incident).

Scores per incident:
  1. Attack vs normal
  2. Attack type (did it name the right class?)
  3. MITRE technique (is it a correct technique for that class?)
and records how many evidence rounds each investigation used.
"""

import time
import pandas as pd

from pipeline import build_pipeline, build_incident, evidence_summary
from build_kb import CLASS_TO_TECHNIQUES

ATTACK_INCIDENTS = 2       # incidents per attack type
FLOWS_PER_INCIDENT = 200
PAUSE_SECONDS = 20         # avoid API rate limits
SEED = 42


def make_batches(flows, label, n_incidents):
    """Split a shuffled pool into non-overlapping incidents of 200 flows.
    Flows left over after the incidents become the extra-evidence pool."""
    pool = flows.sample(frac=1, random_state=SEED).reset_index(drop=True)
    batches = []
    for i in range(n_incidents):
        chunk = pool.iloc[i * FLOWS_PER_INCIDENT:(i + 1) * FLOWS_PER_INCIDENT]
        if len(chunk) < FLOWS_PER_INCIDENT:
            break
        batches.append(build_incident(chunk, label))
    extra = pool.iloc[len(batches) * FLOWS_PER_INCIDENT:].reset_index(drop=True)
    return batches, extra


def norm(text):
    return (text or "").strip().lower()


print("=" * 72)
print("BLIND MULTI-CLASS PIPELINE EVALUATION (with evidence gathering)")
print("=" * 72)

df = pd.read_csv("data/holdout_multi.csv")
benign = df[df["Label"] == "BENIGN"]

groups = []
for label in sorted(df["Label"].unique()):
    if label != "BENIGN":
        groups.append((f"{label}", df[df["Label"] == label], label, ATTACK_INCIDENTS))

groups += [
    ("Benign mixed traffic", benign, "BENIGN", 2),
    ("Benign HTTP (80)", benign[benign["Destination Port"] == 80], "BENIGN", 2),
    ("Benign HTTPS (443)", benign[benign["Destination Port"] == 443], "BENIGN", 2),
    ("Benign SSH (22)", benign[benign["Destination Port"] == 22], "BENIGN", 1),
    ("Benign FTP (21)", benign[benign["Destination Port"] == 21], "BENIGN", 1),
]

incidents = []
print("\nBuilding incidents:")
for name, flows, label, n in groups:
    batches, extra = make_batches(flows, label, n)
    print(f"  {name:<26} {len(flows):>8,} flows -> {len(batches)} incident(s), "
          f"{len(extra):>6,} flows kept as extra evidence")
    incidents += [(name, text, truth, extra) for text, truth in batches]

print(f"\nTotal: {len(incidents)} incidents\n")

pipeline = build_pipeline()
rows = []

for i, (group, alert_text, truth, extra) in enumerate(incidents, 1):
    truth_is_attack = truth != "BENIGN"
    try:
        result = pipeline.invoke({"alert_text": alert_text, "ground_truth": truth,
                                  "evidence_pool": extra})
        f = result["log_findings"]
        t = result["threat_assessment"]
        r = result["risk_assessment"]
        checks = result.get("evidence_checks") or []

        predicted_attack = bool(t.get("is_attack"))
        predicted_class = f.get("attack_type") if predicted_attack else "BENIGN"
        technique = t.get("matched_technique_id")

        if truth_is_attack:
            type_ok = norm(predicted_class) == norm(truth)
            tech_ok = technique in CLASS_TO_TECHNIQUES.get(truth, [])
        else:
            type_ok = not predicted_attack
            tech_ok = technique is None

        rounds = int(result.get("evidence_rounds", 0) or 0)
        rows.append({
            "incident": i, "group": group, "ground_truth": truth,
            "truth_is_attack": truth_is_attack, "predicted_is_attack": predicted_attack,
            "predicted_class": predicted_class, "attack_type_text": t.get("attack_type"),
            "technique": technique, "confidence": t.get("confidence"),
            "severity": r.get("severity"),
            "evidence_rounds": rounds,
            "evidence_conflict": any(c["agrees"] is False for c in checks),
            "evidence_summary": evidence_summary(result) if rounds else None,
            "caveats": t.get("caveats"),
            "detect_ok": predicted_attack == truth_is_attack,
            "type_ok": type_ok, "technique_ok": tech_ok, "error": None,
        })
        mark = "OK  " if type_ok else "MISS"
        ev = f"+{rounds} evidence" if rounds else ""
        print(f"  [{i:>2}/{len(incidents)}] {mark} truth={truth:<17} predicted={predicted_class or 'None':<17} "
              f"{technique or '':<10} conf={t.get('confidence')} {ev}")

    except Exception as e:
        rows.append({"incident": i, "group": group, "ground_truth": truth,
                     "truth_is_attack": truth_is_attack, "predicted_is_attack": None,
                     "predicted_class": None, "attack_type_text": None, "technique": None,
                     "confidence": None, "severity": None, "evidence_rounds": 0,
                     "evidence_conflict": False, "evidence_summary": None, "caveats": None,
                     "detect_ok": False, "type_ok": False, "technique_ok": False,
                     "error": str(e)[:120]})
        print(f"  [{i:>2}/{len(incidents)}] ERR  {truth:<17} {str(e)[:60]}")

    time.sleep(PAUSE_SECONDS)

res = pd.DataFrame(rows)
res.to_csv("evaluation_multi_results.csv", index=False)
valid = res[res["error"].isna()]

print("\n" + "=" * 72)
print("RESULTS")
print("=" * 72)
print(f"Incidents evaluated : {len(valid)}  (errors: {len(res) - len(valid)})")

t_att = valid["truth_is_attack"].astype(bool)
p_att = valid["predicted_is_attack"].astype(bool)
tp, tn = int((t_att & p_att).sum()), int((~t_att & ~p_att).sum())
fp, fn = int((~t_att & p_att).sum()), int((t_att & ~p_att).sum())
print("\n1. Attack vs normal")
print(f"   Accuracy {(tp + tn) / max(len(valid), 1):.1%}   TP {tp}  TN {tn}  FP {fp}  FN {fn}")

attacks = valid[t_att]
print("\n2. Attack type identified correctly")
print(f"   {int(attacks['type_ok'].sum())}/{len(attacks)} attack incidents "
      f"({attacks['type_ok'].mean():.1%})")

print("\n3. Correct MITRE technique")
print(f"   {int(attacks['technique_ok'].sum())}/{len(attacks)} attack incidents "
      f"({attacks['technique_ok'].mean():.1%})")

gathered = valid[valid["evidence_rounds"] > 0]
print("\n4. Evidence gathering")
print(f"   {len(gathered)}/{len(valid)} investigations asked for more evidence "
      f"({int(valid['evidence_rounds'].sum())} extra rounds in total)")
print(f"   Conflicts escalated to an analyst: {int(valid['evidence_conflict'].sum())}")
for _, g in gathered.iterrows():
    print(f"     #{g.incident} {g.group}: {g.evidence_rounds} round(s), final confidence {g.confidence}")

print("\nPer class (type correct / incidents):")
for cls, g in valid.groupby("ground_truth"):
    print(f"   {cls:<18} {int(g['type_ok'].sum())}/{len(g)}")

misses = valid[~valid["type_ok"]]
if len(misses):
    print(f"\nMisclassified ({len(misses)}):")
    for _, m in misses.iterrows():
        print(f"   #{m.incident} {m.group}: predicted {m.predicted_class}")

print("\nFull results written to evaluation_multi_results.csv")