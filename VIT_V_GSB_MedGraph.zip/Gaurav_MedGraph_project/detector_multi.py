"""
Multi-class flow detector used as the perception layer of the pipeline.
For an incident (a batch of flows), it reports how the flows split across
attack types, which the agents then investigate and explain.
"""

import joblib
import numpy as np
import pandas as pd

_bundle = joblib.load("detector_multi.joblib")
MODEL = _bundle["model"]
FEATURES = _bundle["features"]
CLASSES = _bundle["classes"]


def score_flows(flows):
    """Classify every flow and summarise the incident by attack type."""
    X = (flows[FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0)).astype("float32")
    probs = MODEL.predict_proba(X)
    preds = np.array(CLASSES)[probs.argmax(axis=1)]

    n = len(flows)
    shares = pd.Series(preds).value_counts()
    breakdown = []
    for cls, count in shares.items():
        mask = preds == cls
        breakdown.append({
            "class": cls,
            "flows": int(count),
            "pct": round(100 * count / n, 1),
            "mean_confidence": round(float(probs[mask].max(axis=1).mean()), 3),
        })

    attacks = [b for b in breakdown if b["class"] != "BENIGN"]
    pct_attack = round(sum(b["pct"] for b in attacks), 1)
    dominant = attacks[0] if attacks else None

    return {
        "flows_analysed": n,
        "pct_flagged": pct_attack,
        "breakdown": breakdown,
        "dominant_attack": dominant["class"] if dominant else None,
        "dominant_pct": dominant["pct"] if dominant else 0.0,
    }


def describe_detection(result):
    """Render the detector output as text for the agents."""
    lines = [
        "Automated Detector Output (multi-class)",
        f"Flows analysed: {result['flows_analysed']}",
        f"Flows classified as an attack type: {result['pct_flagged']}%",
        "Breakdown of flows by predicted class:",
    ]
    for b in result["breakdown"]:
        lines.append(f"  - {b['class']}: {b['flows']} flows ({b['pct']}%), "
                     f"mean confidence {b['mean_confidence']}")
    return "\n".join(lines)


if __name__ == "__main__":
    # Self-test: one 200-flow incident per class from the held-out data.
    print("Loading held-out flows...")
    df = pd.read_csv("data/holdout_multi.csv")
    print(f"{'True class':<18} {'Flagged':>8}  {'Dominant prediction':<20} {'Share':>6}")
    print("-" * 60)
    for label in sorted(df["Label"].unique()):
        pool = df[df["Label"] == label]
        if len(pool) < 200:
            print(f"{label:<18} (only {len(pool)} flows, skipped)")
            continue
        r = score_flows(pool.sample(200, random_state=42))
        dom = r["dominant_attack"] or "none (benign)"
        print(f"{label:<18} {r['pct_flagged']:>7}%  {dom:<20} {r['dominant_pct']:>5}%")